@echo off
setlocal
title RobloxScripter Server
cd /d "%~dp0"
call "%~dp0scripts\ensure-node.cmd"
if errorlevel 1 (
  pause
  exit /b 1
)
echo Starting the RobloxScripter server. The dashboard opens in your browser.
echo Script sync folder: %~dp0src  (open it in VS Code / Cursor)
echo Keep this window open while you work. Close it to stop the server.
echo.
"%RS_NODE%" server\server.js --open
echo.
echo The server stopped.
pause
