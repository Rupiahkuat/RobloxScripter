@echo off
rem Mencari Node.js 16+ (PATH, Program Files, atau salinan portabel di runtime\node).
rem Kalau tidak ada: mengunduh otomatis. Hasilnya: variabel RS_NODE = path node.exe.
rem Dipakai dengan:  call "%~dp0scripts\ensure-node.cmd"   (exit code 1 = gagal)
set "RS_NODE="
for %%I in (node.exe) do if not "%%~$PATH:I"=="" call :try "%%~$PATH:I"
if not defined RS_NODE if exist "%ProgramFiles%\nodejs\node.exe" call :try "%ProgramFiles%\nodejs\node.exe"
if not defined RS_NODE if exist "%~dp0..\runtime\node\node.exe" call :try "%~dp0..\runtime\node\node.exe"
if defined RS_NODE exit /b 0

echo.
echo  Node.js belum ada di komputer ini, jadi RobloxScripter menyiapkannya sendiri.
echo  Unduhan sekitar 30 MB, hanya sekali, tanpa perlu hak admin. Mohon tunggu...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0get-node.ps1" -Dest "%~dp0..\runtime\node"
if errorlevel 1 goto :fail
call :try "%~dp0..\runtime\node\node.exe"
if defined RS_NODE exit /b 0

:fail
echo.
echo  [!] Node.js gagal disiapkan otomatis (cek koneksi internet / antivirus).
echo      Pasang manual dari https://nodejs.org lalu jalankan file ini lagi.
start "" "https://nodejs.org/en/download"
exit /b 1

:try
"%~1" -e "process.exit(+process.versions.node.split('.')[0]>=16?0:1)" >nul 2>nul
if not errorlevel 1 set "RS_NODE=%~1"
exit /b 0
