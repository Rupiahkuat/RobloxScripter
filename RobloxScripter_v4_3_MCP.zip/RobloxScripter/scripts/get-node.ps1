# RobloxScripter - unduh Node.js LTS portabel ke folder runtime\node (tanpa admin, tanpa installer).
# Dipanggil otomatis oleh scripts\ensure-node.cmd. Zip diverifikasi dengan SHA-256 resmi dari nodejs.org.
param([Parameter(Mandatory = $true)][string]$Dest)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # tanpa ini Invoke-WebRequest di PowerShell 5 sangat lambat
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$arch = 'x64'
if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'arm64' }
elseif ($env:PROCESSOR_ARCHITECTURE -eq 'x86' -and $env:PROCESSOR_ARCHITEW6432 -ne 'AMD64') { $arch = 'x86' }

Write-Host '  - Mencari versi Node.js LTS terbaru...'
$index = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -UseBasicParsing
$rel = $index | Where-Object { $_.lts -and ($_.files -contains "win-$arch-zip") } | Select-Object -First 1
if (-not $rel) { throw "Tidak ada build Node.js LTS untuk win-$arch" }
$ver = $rel.version
$name = "node-$ver-win-$arch"
$zip = Join-Path $env:TEMP "$name.zip"

Write-Host "  - Mengunduh Node.js $ver ($arch)..."
Invoke-WebRequest -Uri "https://nodejs.org/dist/$ver/$name.zip" -OutFile $zip -UseBasicParsing

Write-Host '  - Memeriksa keaslian file (SHA-256)...'
$sumsRaw = (Invoke-WebRequest -Uri "https://nodejs.org/dist/$ver/SHASUMS256.txt" -UseBasicParsing).Content
if ($sumsRaw -is [byte[]]) { $sumsRaw = [Text.Encoding]::UTF8.GetString($sumsRaw) }
$line = $sumsRaw -split "`n" | Where-Object { $_ -match ([regex]::Escape("$name.zip") + '\s*$') } | Select-Object -First 1
if (-not $line) { throw 'Checksum untuk file ini tidak ditemukan' }
$expected = ($line.Trim() -split '\s+')[0].ToLower()
$actual = (Get-FileHash -Path $zip -Algorithm SHA256).Hash.ToLower()
if ($expected -ne $actual) { Remove-Item $zip -Force; throw 'Checksum tidak cocok: unduhan dibatalkan demi keamanan' }

Write-Host '  - Memasang...'
$tmp = Join-Path $env:TEMP 'rs_node_extract'
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
Expand-Archive -Path $zip -DestinationPath $tmp -Force
if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Dest) | Out-Null
Move-Item -Path (Join-Path $tmp $name) -Destination $Dest
Remove-Item $zip -Force -ErrorAction SilentlyContinue
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
if (-not (Test-Path (Join-Path $Dest 'node.exe'))) { throw 'node.exe tidak ditemukan setelah pemasangan' }
Write-Host "  - Selesai: Node.js $ver terpasang di folder runtime (hanya untuk RobloxScripter)."
