@echo off
setlocal
cd /d "%~dp0"
echo [1/3] Memeriksa Node.js...
call "%~dp0scripts\ensure-node.cmd"
if errorlevel 1 (
  pause
  exit /b 1
)
echo       OK: %RS_NODE%
echo.
echo [2/3] Memasang plugin Studio...
set "PLUG=%LOCALAPPDATA%\Roblox\Plugins"
if not exist "%PLUG%" mkdir "%PLUG%"
copy /Y "plugin\RobloxScripterBridge.server.lua" "%PLUG%\RobloxScripterBridge.server.lua" >nul
if errorlevel 1 (
  echo [!] Could not copy the plugin to: %PLUG%
  pause
  exit /b 1
)
echo       OK: %PLUG%
echo.
echo [3/3] Menyiapkan folder sinkron script (src)...
if not exist "src" mkdir "src"
echo       OK: %~dp0src
echo.
echo Next steps:
echo   1. Restart Roblox Studio, then open Plugins ^> RobloxScripter and click Allow if asked.
echo   2. In the dashboard that opens, click "Connect Studio plugin".
echo   3. Add the MCP server to your AI client: see README.txt (file mcp-config.example.json).
echo   4. (Optional) Open the "src" folder in VS Code / Cursor to edit scripts there.
echo.
call "%~dp0Start.bat"
