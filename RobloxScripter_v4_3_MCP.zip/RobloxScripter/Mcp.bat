@echo off
rem Launcher MCP (stdio) untuk AI client. Jangan tulis apa pun ke stdout di sini.
setlocal
cd /d "%~dp0"
call "%~dp0scripts\ensure-node.cmd" >nul 2>&1
if errorlevel 1 exit /b 1
"%RS_NODE%" "%~dp0server\mcp.js"
