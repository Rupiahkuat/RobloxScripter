--[[
	RobloxScripter Bridge v4.2 - plugin Studio
	Menghubungkan Studio ke server lokal (node server.js). Perintah datang dari ekstensi browser.
	Pasang: simpan sebagai %LOCALAPPDATA%\Roblox\Plugins\RobloxScripterBridge.server.lua
	(atau klik kanan Script > "Save as Local Plugin..."), lalu restart Studio.
	Buka: Plugins > RobloxScripter. Klik Allow untuk izin HTTP ke 127.0.0.1:3030,
	lalu tempel TOKEN (ditampilkan di console server.js) ke kolom token di panel.

	v4.2: tool internal dump_scripts + sync_script (Local File Syncing, Script History/Undo), batch 'quiet'.
	v4: 32 tool (baru: bulk_set_properties, replace_in_scripts, script_outline, group_instances,
	    arrange_instances, scatter_instances; terrain "hills"; get_script_source per baris),
	    UI panel baru (kartu log, segmented review, switch rollback, statistik, review per-aksi).
	v3: token keamanan, batch atomik, project_snapshot, verify, create_gui, run_luau, playtest.
]]

local HttpService = game:GetService("HttpService")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local Selection = game:GetService("Selection")
local RunService = game:GetService("RunService")
local LogService = game:GetService("LogService")
local InsertService = game:GetService("InsertService")
local CollectionService = game:GetService("CollectionService")

local BASE = "http://127.0.0.1:3030"
local SID = HttpService:GenerateGUID(false)

local IS_EDIT = RunService:IsEdit()
local CONTEXT = IS_EDIT and "Edit" or (RunService:IsServer() and "Server" or "Client")

local function authHeaders()
	return {
		["Content-Type"] = "application/json",
		["X-RS-Token"] = tostring(plugin:GetSetting("RS_Token") or ""),
	}
end

local function request(path, method, bodyTable)
	local r = { Url = BASE .. path, Method = method or "GET", Headers = authHeaders() }
	if bodyTable ~= nil then
		r.Body = HttpService:JSONEncode(bodyTable)
	end
	return HttpService:RequestAsync(r)
end

local forwardState = { suppress = false }

------------------------------------------------------------------
-- AUTO-DEBUG: teruskan error/warning Output ke server
-- (jalan di semua DataModel: Edit, dan Server/Client saat playtest)
------------------------------------------------------------------
do
	local pendingItems = {}
	local flushScheduled = false
	local lastErr, lastErrT = nil, 0

	local function flushEvents()
		flushScheduled = false
		if #pendingItems == 0 then
			return
		end
		local merged, index = {}, {}
		for _, it in ipairs(pendingItems) do
			local k = it.level .. "|" .. it.msg
			if index[k] then
				index[k].count = index[k].count + 1
			else
				it.count = 1
				index[k] = it
				table.insert(merged, it)
			end
		end
		pendingItems = {}
		local out = {}
		for i, it in ipairs(merged) do
			if i > 50 then
				break
			end
			table.insert(out, { level = it.level, msg = it.msg .. (it.count > 1 and (" (x" .. it.count .. ")") or "") })
		end
		pcall(request, "/events", "POST", { source = CONTEXT, items = out })
	end

	LogService.MessageOut:Connect(function(message, mtype)
		if forwardState.suppress then
			return
		end
		if string.find(message, "127.0.0.1:3030", 1, true) or string.find(message, "RobloxScripter", 1, true) then
			return
		end
		if mtype == Enum.MessageType.MessageError or mtype == Enum.MessageType.MessageWarning then
			local it = {
				level = (mtype == Enum.MessageType.MessageError) and "error" or "warning",
				msg = string.sub(message, 1, 1000),
			}
			table.insert(pendingItems, it)
			if it.level == "error" then
				lastErr, lastErrT = it, os.clock()
			end
			if not flushScheduled then
				flushScheduled = true
				task.delay(1.5, flushEvents)
			end
		elseif lastErr and os.clock() - lastErrT < 0.5
			and (string.find(message, "^Stack") or string.find(message, "Script '")) then
			-- baris stack trace yang menyusul error: tempel ke error terakhir
			if #lastErr.msg < 1500 then
				lastErr.msg = lastErr.msg .. "\n" .. string.sub(message, 1, 300)
			end
			lastErrT = os.clock()
		end
	end)
end

-- Playtest otomatis (dipakai tool playtest): DataModel server mengakhiri sesi setelah rs_duration detik.
if not IS_EDIT and RunService:IsRunning() and RunService:IsServer() then
	task.spawn(function()
		local ok, STS = pcall(function()
			return game:GetService("StudioTestService")
		end)
		if not ok or not STS then
			return
		end
		local ok2, args = pcall(function()
			return STS:GetTestArgs()
		end)
		if ok2 and type(args) == "table" and tonumber(args.rs_duration) then
			task.delay(tonumber(args.rs_duration), function()
				pcall(function()
					STS:EndTest({ rs_ended = true })
				end)
			end)
		end
	end)
end

-- Saat playtest, plugin juga dimuat di DataModel Server/Client: cukup forwarder error di atas.
if not IS_EDIT then
	return
end

------------------------------------------------------------------
-- HELPER
------------------------------------------------------------------
-- path: "Workspace.Map.Door", "Workspace.Part#2" (anak ke-2 bernama Part),
-- nama yang mengandung titik didukung, atau array {"Workspace","My.Part"}
local function resolve(path)
	if path == nil or path == "" or path == "game" then
		return game
	end
	local segs = {}
	if type(path) == "table" then
		for _, s in ipairs(path) do
			table.insert(segs, tostring(s))
		end
	else
		path = string.gsub(tostring(path), "^game%.", "")
		for s in string.gmatch(path, "[^%.]+") do
			table.insert(segs, s)
		end
	end
	local label = type(path) == "table" and table.concat(segs, ".") or path
	local cur = game
	local i = 1
	while i <= #segs do
		local found = nil
		for j = i, #segs do
			local name = table.concat(segs, ".", i, j)
			local idx = nil
			local base, n = string.match(name, "^(.-)#(%d+)$")
			if base then
				name = base
				idx = tonumber(n)
			end
			local nxt = nil
			if idx then
				local c = 0
				for _, ch in ipairs(cur:GetChildren()) do
					if ch.Name == name then
						c = c + 1
						if c == idx then
							nxt = ch
							break
						end
					end
				end
			else
				nxt = cur:FindFirstChild(name)
			end
			if not nxt and cur == game then
				local ok, svc = pcall(function()
					return game:GetService(name)
				end)
				if ok then
					nxt = svc
				end
			end
			if nxt then
				found = nxt
				i = j + 1
				break
			end
		end
		if not found then
			error("Path tidak ditemukan: " .. label .. " (gagal di '" .. tostring(segs[i]) .. "')")
		end
		cur = found
	end
	return cur
end

local function str(v)
	if type(v) == "table" then
		return table.concat(v, "\n")
	end
	return v
end

local function ser(v)
	local t = typeof(v)
	if t == "Vector3" then
		return { v.X, v.Y, v.Z }
	elseif t == "Vector2" then
		return { v.X, v.Y }
	elseif t == "Color3" then
		return { math.round(v.R * 255), math.round(v.G * 255), math.round(v.B * 255) }
	elseif t == "CFrame" then
		local rx, ry, rz = v:ToEulerAnglesXYZ()
		return { position = { v.X, v.Y, v.Z }, rotation_deg = { math.deg(rx), math.deg(ry), math.deg(rz) } }
	elseif t == "UDim2" then
		return { v.X.Scale, v.X.Offset, v.Y.Scale, v.Y.Offset }
	elseif t == "UDim" then
		return { v.Scale, v.Offset }
	elseif t == "EnumItem" or t == "BrickColor" then
		return v.Name
	elseif t == "Instance" then
		return v:GetFullName()
	elseif t == "string" or t == "number" or t == "boolean" then
		return v
	end
	return tostring(v)
end

-- Tema UI (dipakai create_gui; token ditulis "$nama")
local THEMES = {
	dark = { bg = { 18, 18, 22 }, surface = { 30, 30, 36 }, surface2 = { 46, 46, 56 }, primary = { 10, 132, 255 }, accent = { 255, 159, 10 }, text = { 236, 236, 241 }, subtext = { 160, 160, 172 }, danger = { 255, 69, 58 }, success = { 48, 209, 88 } },
	light = { bg = { 242, 242, 247 }, surface = { 255, 255, 255 }, surface2 = { 229, 229, 234 }, primary = { 0, 122, 255 }, accent = { 255, 149, 0 }, text = { 28, 28, 30 }, subtext = { 99, 99, 102 }, danger = { 255, 59, 48 }, success = { 52, 199, 89 } },
	neon = { bg = { 8, 6, 20 }, surface = { 20, 16, 44 }, surface2 = { 36, 28, 76 }, primary = { 0, 255, 200 }, accent = { 255, 0, 153 }, text = { 240, 240, 255 }, subtext = { 150, 140, 200 }, danger = { 255, 60, 90 }, success = { 80, 255, 140 } },
}
local activeTheme = nil

local function themeColor(name)
	local t = activeTheme and activeTheme[name]
	if not t then
		error("Token tema '$" .. tostring(name) .. "' tidak tersedia (pakai tool create_gui dengan theme, atau beri warna [r,g,b])")
	end
	return Color3.fromRGB(t[1], t[2], t[3])
end

local function colorFrom(v)
	if type(v) == "string" then
		local c = string.sub(v, 1, 1)
		if c == "$" then
			return themeColor(string.sub(v, 2))
		elseif c == "#" then
			return Color3.fromHex(v)
		end
		error("Warna string tidak valid: " .. v .. " (pakai \"$token\", \"#RRGGBB\", atau [r,g,b])")
	end
	return Color3.fromRGB(v[1], v[2], v[3])
end

local function convert(inst, prop, v)
	local ok, current = pcall(function()
		return inst[prop]
	end)
	if not ok then
		error("Properti '" .. prop .. "' tidak ada di " .. inst.ClassName)
	end
	local t = typeof(current)
	if t == "Vector3" then
		return Vector3.new(v[1], v[2], v[3])
	elseif t == "Vector2" then
		return Vector2.new(v[1], v[2])
	elseif t == "Color3" then
		return colorFrom(v)
	elseif t == "BrickColor" then
		return BrickColor.new(v)
	elseif t == "UDim2" then
		return UDim2.new(v[1], v[2], v[3], v[4])
	elseif t == "UDim" then
		return UDim.new(v[1], v[2])
	elseif t == "NumberRange" then
		if type(v) == "table" then
			return NumberRange.new(v[1], v[2] or v[1])
		end
		return NumberRange.new(v)
	elseif t == "NumberSequence" then
		if type(v) == "table" then
			return NumberSequence.new(v[1], v[2] or v[1])
		end
		return NumberSequence.new(v)
	elseif t == "ColorSequence" then
		if type(v[1]) == "number" or type(v) == "string" then
			return ColorSequence.new(colorFrom(v))
		end
		local kps = {}
		local n = #v
		for k, c in ipairs(v) do
			table.insert(kps, ColorSequenceKeypoint.new(n == 1 and 0 or (k - 1) / (n - 1), colorFrom(c)))
		end
		if n == 1 then
			table.insert(kps, ColorSequenceKeypoint.new(1, colorFrom(v[1])))
		end
		return ColorSequence.new(kps)
	elseif t == "Font" then
		if type(v) == "string" then
			return Font.fromName(v)
		end
		return v
	elseif t == "CFrame" then
		if #v >= 6 then
			return CFrame.new(v[1], v[2], v[3]) * CFrame.Angles(math.rad(v[4]), math.rad(v[5]), math.rad(v[6]))
		end
		return CFrame.new(v[1], v[2], v[3])
	elseif t == "EnumItem" then
		for _, item in ipairs(current.EnumType:GetEnumItems()) do
			if item.Name == v then
				return item
			end
		end
		error("Enum '" .. tostring(v) .. "' tidak valid untuk " .. prop)
	elseif t == "Instance" or (t == "nil" and type(v) == "string") then
		return resolve(v)
	end
	return v
end

local function applyProps(inst, props)
	if type(props) ~= "table" then
		return
	end
	for k, v in pairs(props) do
		inst[k] = convert(inst, k, v)
	end
end

local function getMaterial(name)
	local ok, mat = pcall(function()
		return Enum.Material[name or "Grass"]
	end)
	if not ok then
		error("Material tidak valid: " .. tostring(name))
	end
	return mat
end

local function vec(t, default)
	t = t or default
	return Vector3.new(t[1], t[2], t[3])
end

local function httpGet(path)
	local res = request(path, "GET")
	if not res.Success then
		error("Server error " .. tostring(res.StatusCode))
	end
	return HttpService:JSONDecode(res.Body)
end

------------------------------------------------------------------
-- KEAMANAN & SYNTAX
------------------------------------------------------------------
local B64 = string.rep("[%w+/=]", 160)
local DANGER = {
	{ "require%s*%(%s*%d", "require() dengan asset ID angka (pola backdoor umum)" },
	{ "getfenv", "memakai getfenv" },
	{ "setfenv", "memakai setfenv" },
	{ "loadstring", "memakai loadstring (eksekusi kode dinamis)" },
	{ "HttpService", "mengakses HttpService (jaringan keluar)" },
	{ "InsertService", "memakai InsertService (memuat asset dari luar)" },
	{ B64, "string panjang mirip base64 (kemungkinan kode tersamar)" },
	{ "\\%d%d%d\\%d%d%d\\%d%d%d\\%d%d%d", "banyak escape numerik (kemungkinan obfuscation)" },
}

local function scanCode(src)
	local warns = {}
	if type(src) ~= "string" then
		return warns
	end
	for _, d in ipairs(DANGER) do
		if string.find(src, d[1]) then
			table.insert(warns, d[2])
		end
	end
	return warns
end

local function warnSuffix(src)
	local w = scanCode(src)
	if #w == 0 then
		return ""
	end
	return "\n⚠ Periksa: " .. table.concat(w, "; ")
end

local canLoad = pcall(function()
	local f = loadstring("return 1")
	assert(f)
end)

-- nil = OK / tidak bisa dicek; string = pesan error syntax
local function syntaxError(src)
	if not canLoad then
		return nil
	end
	local ok, f, err = pcall(loadstring, src, "=check")
	if ok and not f then
		return tostring(err)
	end
	return nil
end

-- cari panggilan fungsi global "name(" yang bukan task.name( / obj:name( / obj.name(
local function findBare(src, name)
	local pat = "()" .. name .. "%s*%("
	for pos in string.gmatch(src, pat) do
		local before = string.sub(src, pos - 1, pos - 1)
		if before == "" or not string.find(before, "[%w_%.:]") then
			return true
		end
	end
	return false
end

-- Hitung hasil edit_script (dipakai oleh eksekusi DAN preview review)
local function computeEdit(s, a)
	if a.source then
		return str(a.source)
	end
	if a.find then
		local find = str(a.find)
		local src = s.Source
		local i, j = string.find(src, find, 1, true)
		if not i then
			error("Teks 'find' tidak ditemukan di script")
		end
		if string.find(src, find, j + 1, true) then
			error("Teks 'find' muncul lebih dari sekali, buat lebih spesifik")
		end
		return string.sub(src, 1, i - 1) .. (str(a.replace) or "") .. string.sub(src, j + 1)
	end
	error("Beri 'source' atau 'find'+'replace'")
end

local function setScriptSource(s, newSrc)
	local SES = game:GetService("ScriptEditorService")
	local ok = pcall(function()
		SES:UpdateSourceAsync(s, function()
			return newSrc
		end)
	end)
	if not ok then
		s.Source = newSrc
	end
end

local SCRIPT_ROOTS = { "Workspace", "ServerScriptService", "ReplicatedStorage", "ReplicatedFirst", "ServerStorage", "StarterGui", "StarterPack", "StarterPlayer", "Lighting" }

local function eachRoot()
	local roots = {}
	for _, name in ipairs(SCRIPT_ROOTS) do
		local ok, svc = pcall(function()
			return game:GetService(name)
		end)
		if ok then
			table.insert(roots, svc)
		end
	end
	return roots
end

------------------------------------------------------------------
-- TOOLS
------------------------------------------------------------------
local impl = {}

function impl.list_children(a)
	local root = resolve(a.path)
	local maxDepth = math.clamp(a.depth or 1, 1, 4)
	local lines, count = {}, 0
	local function walk(inst, d)
		for _, c in ipairs(inst:GetChildren()) do
			count = count + 1
			if count > 200 then
				return
			end
			table.insert(lines, string.rep("  ", d - 1) .. c.Name .. " [" .. c.ClassName .. "]")
			if d < maxDepth then
				walk(c, d + 1)
			end
		end
	end
	walk(root, 1)
	if #lines == 0 then
		return "(kosong)"
	end
	if count > 200 then
		table.insert(lines, "... (dipotong di 200 baris)")
	end
	return table.concat(lines, "\n")
end

function impl.find_instances(a)
	local root = resolve(a.root or "Workspace")
	local limit = math.clamp(a.limit or 50, 1, 200)
	local nm = a.name_contains and string.lower(tostring(a.name_contains)) or nil
	local lines = {}
	for _, d in ipairs(root:GetDescendants()) do
		local okClass = (not a.class_name) or d:IsA(a.class_name)
		local okName = (not nm) or string.find(string.lower(d.Name), nm, 1, true) ~= nil
		if okClass and okName then
			table.insert(lines, d:GetFullName() .. " [" .. d.ClassName .. "]")
			if #lines >= limit then
				table.insert(lines, "... (dibatasi " .. limit .. " hasil)")
				break
			end
		end
	end
	if #lines == 0 then
		return "(tidak ditemukan)"
	end
	return table.concat(lines, "\n")
end

function impl.get_properties(a)
	local inst = resolve(a.path)
	local out = {}
	for _, p in ipairs(a.properties or {}) do
		local ok, v = pcall(function()
			return inst[p]
		end)
		out[p] = ok and ser(v) or "(tidak ada)"
	end
	return HttpService:JSONEncode(out)
end

function impl.get_selection()
	local t = {}
	for _, o in ipairs(Selection:Get()) do
		table.insert(t, o:GetFullName() .. " [" .. o.ClassName .. "]")
	end
	return #t > 0 and table.concat(t, "\n") or "(tidak ada yang dipilih)"
end

function impl.create_instance(a)
	local parent = resolve(a.parent_path)
	local inst = Instance.new(a.class_name)
	if a.name then
		inst.Name = a.name
	end
	applyProps(inst, a.properties)
	inst.Parent = parent
	return "Dibuat: " .. inst:GetFullName()
end

function impl.set_properties(a)
	local inst = resolve(a.path)
	applyProps(inst, a.properties)
	return "Diubah: " .. inst:GetFullName()
end

function impl.move_instance(a)
	local inst = resolve(a.path)
	inst.Parent = resolve(a.new_parent_path)
	return "Dipindah ke: " .. inst:GetFullName()
end

function impl.delete_instance(a)
	local inst = resolve(a.path)
	if inst == game or inst.Parent == game then
		error("Tidak boleh menghapus service/root: " .. tostring(a.path))
	end
	local name = inst:GetFullName()
	inst:Destroy()
	return "Dihapus: " .. name
end

function impl.clone_instance(a)
	local src = resolve(a.path)
	local parent = a.parent_path and resolve(a.parent_path) or src.Parent
	if not parent then
		error("parent tidak ditemukan")
	end
	local count = math.clamp(a.count or 1, 1, 100)
	local off = a.offset
	local first, last
	for i = 1, count do
		local c = src:Clone()
		if not c then
			error(src.Name .. " tidak bisa di-clone (Archivable=false)")
		end
		if a.name then
			c.Name = (count > 1) and (a.name .. i) or a.name
		end
		if off and c:IsA("PVInstance") then
			c:PivotTo(src:GetPivot() + Vector3.new(off[1] * i, off[2] * i, off[3] * i))
		end
		applyProps(c, a.properties)
		c.Parent = parent
		first = first or c.Name
		last = c.Name
	end
	return "Di-clone " .. count .. "x ke " .. parent:GetFullName() .. ": " .. first .. ((count > 1) and (" … " .. last) or "")
end

function impl.set_attributes(a)
	local inst = resolve(a.path)
	local n = 0
	for k, v in pairs(a.attributes or {}) do
		local tv = type(v)
		if tv ~= "string" and tv ~= "number" and tv ~= "boolean" then
			error("Attribute '" .. tostring(k) .. "': hanya string/number/boolean")
		end
		inst:SetAttribute(k, v)
		n = n + 1
	end
	return n .. " attribute diset di " .. inst:GetFullName()
end

function impl.tag(a)
	local inst = resolve(a.path)
	for _, t in ipairs(a.add or {}) do
		CollectionService:AddTag(inst, tostring(t))
	end
	for _, t in ipairs(a.remove or {}) do
		CollectionService:RemoveTag(inst, tostring(t))
	end
	return "Tag sekarang di " .. inst:GetFullName() .. ": " .. table.concat(CollectionService:GetTags(inst), ", ")
end

function impl.create_script(a)
	local parent = resolve(a.parent_path)
	if a.script_type ~= "Script" and a.script_type ~= "LocalScript" and a.script_type ~= "ModuleScript" then
		error("script_type harus Script, LocalScript, atau ModuleScript")
	end
	local src = str(a.source) or ""
	local serr = syntaxError(src)
	if serr then
		error("Syntax error di source (script TIDAK dibuat): " .. serr)
	end
	local s = Instance.new(a.script_type)
	s.Name = a.name
	s.Source = src
	if a.script_type == "Script" and a.run_context then
		s.RunContext = Enum.RunContext[a.run_context]
	end
	s.Parent = parent
	return "Script dibuat: " .. s:GetFullName() .. " (" .. (select(2, string.gsub(src, "\n", "\n")) + 1) .. " baris" .. (canLoad and ", syntax OK" or "") .. ")" .. warnSuffix(src)
end

function impl.get_script_source(a)
	local s = resolve(a.path)
	if not s:IsA("LuaSourceContainer") then
		error(tostring(a.path) .. " bukan script")
	end
	local sl, el = tonumber(a.start_line), tonumber(a.end_line)
	if not sl and not el then
		return s.Source
	end
	local lines = {}
	local n = 0
	for line in (s.Source .. "\n"):gmatch("(.-)\n") do
		n = n + 1
		if n >= (sl or 1) and n <= (el or math.huge) then
			table.insert(lines, n .. "| " .. line)
		end
		if el and n > el then
			break
		end
	end
	if #lines == 0 then
		error("rentang baris di luar isi script (" .. n .. " baris)")
	end
	return table.concat(lines, "\n")
end

function impl.edit_script(a)
	local s = resolve(a.path)
	if not s:IsA("LuaSourceContainer") then
		error(a.path .. " bukan script")
	end
	local newSrc = computeEdit(s, a)
	local serr = syntaxError(newSrc)
	if serr then
		error("Syntax error setelah edit (script TIDAK diubah): " .. serr)
	end
	setScriptSource(s, newSrc)
	return "Script diedit: " .. s:GetFullName() .. (canLoad and " (syntax OK)" or "") .. warnSuffix(newSrc)
end

-- v4.2: tool internal untuk Local File Syncing / History / Undo.
-- Dipanggil oleh server.js sendiri (server menolak kalau dikirim lewat /commands).
-- dump_scripts : daftar semua script + source (dipecah per chunk supaya aman untuk HttpService)
-- sync_script  : upsert satu script dari file lokal / tombol Undo (tanpa review: aksi berasal dari user)
local function scriptSegs(inst)
	local segs = {}
	local cur = inst
	while cur and cur ~= game do
		local name = cur.Name
		local parent = cur.Parent
		if parent then
			local same, idx = 0, 0
			for _, ch in ipairs(parent:GetChildren()) do
				if ch.Name == name then
					same = same + 1
					if ch == cur then
						idx = same
					end
				end
			end
			if same > 1 then
				name = name .. "#" .. idx
			end
		end
		table.insert(segs, 1, name)
		cur = parent
	end
	return segs
end

function impl.dump_scripts(a)
	local maxBytes = math.clamp(tonumber(a.max_bytes) or 300000, 20000, 600000)
	local startIdx = math.max(math.floor(tonumber(a.after) or 0), 0)
	local all = {}
	for _, root in ipairs(eachRoot()) do
		for _, d in ipairs(root:GetDescendants()) do
			if d:IsA("LuaSourceContainer") then
				local segs = scriptSegs(d)
				table.insert(all, { sortKey = table.concat(segs, "\0"), inst = d, segs = segs })
			end
		end
	end
	table.sort(all, function(x, y)
		return x.sortKey < y.sortKey
	end)
	local items, bytes, nextIdx = {}, 0, nil
	for i = startIdx + 1, #all do
		local e = all[i]
		local okS, src = pcall(function()
			return e.inst.Source
		end)
		if okS and type(src) == "string" then
			local size = #src + 80
			if #items > 0 and bytes + size > maxBytes then
				nextIdx = i - 1
				break
			end
			table.insert(items, { segs = e.segs, class = e.inst.ClassName, source = src })
			bytes = bytes + size
		end
	end
	local okJ, js = pcall(function()
		return HttpService:JSONEncode({ scripts = items, next = nextIdx, total = #all })
	end)
	if not okJ then
		-- ada source yang tidak bisa di-encode (mis. byte tidak valid): saring satu per satu
		local safe = {}
		for _, it in ipairs(items) do
			if pcall(function()
				return HttpService:JSONEncode(it)
			end) then
				table.insert(safe, it)
			end
		end
		js = HttpService:JSONEncode({ scripts = safe, next = nextIdx, total = #all })
	end
	return js
end

function impl.sync_script(a)
	local cls = a.class
	if cls ~= "Script" and cls ~= "LocalScript" and cls ~= "ModuleScript" then
		error("class harus Script, LocalScript, atau ModuleScript")
	end
	local src = str(a.source) or ""
	local serr = syntaxError(src)
	if serr then
		error("Syntax error (script TIDAK diubah): " .. serr)
	end
	local okR, existing = pcall(resolve, a.path)
	if okR and existing ~= game then
		if not existing:IsA("LuaSourceContainer") then
			error(existing:GetFullName() .. " bukan script")
		end
		if existing.ClassName ~= cls then
			error(existing:GetFullName() .. " adalah " .. existing.ClassName .. ", file lokal bertipe " .. cls)
		end
		setScriptSource(existing, src)
		return "Sinkron: " .. existing:GetFullName() .. " (" .. (select(2, string.gsub(src, "\n", "\n")) + 1) .. " baris)"
	end
	if a.create == false then
		error("Script tidak ada di Studio")
	end
	local segs = {}
	if type(a.path) == "table" then
		for _, s2 in ipairs(a.path) do
			table.insert(segs, tostring(s2))
		end
	else
		for s2 in string.gmatch(tostring(a.path), "[^%.]+") do
			table.insert(segs, s2)
		end
	end
	if #segs < 2 then
		error("path script harus berisi parent dan nama")
	end
	local name = table.remove(segs)
	name = string.gsub(name, "#%d+$", "")
	local parent = resolve(segs)
	local s = Instance.new(cls)
	s.Name = name
	s.Source = src
	s.Parent = parent
	return "Dibuat dari file: " .. s:GetFullName()
end

function impl.search_scripts(a)
	local q = str(a.query)
	if not q or q == "" then
		error("query kosong")
	end
	q = string.lower(q)
	local roots
	if a.root then
		roots = { resolve(a.root) }
	else
		roots = eachRoot()
	end
	local hits = {}
	local function scan(inst)
		if inst:IsA("LuaSourceContainer") then
			local n = 0
			for line in (inst.Source .. "\n"):gmatch("(.-)\n") do
				n = n + 1
				if string.find(string.lower(line), q, 1, true) then
					table.insert(hits, inst:GetFullName() .. ":" .. n .. ": " .. string.sub((line:gsub("^%s+", "")), 1, 120))
					if #hits >= 40 then
						return
					end
				end
			end
		end
	end
	for _, r in ipairs(roots) do
		scan(r)
		for _, d in ipairs(r:GetDescendants()) do
			if #hits >= 40 then
				break
			end
			scan(d)
		end
	end
	if #hits == 0 then
		return "(tidak ditemukan)"
	end
	if #hits >= 40 then
		table.insert(hits, "... (dibatasi 40 hasil, persempit query)")
	end
	return table.concat(hits, "\n")
end

function impl.insert_asset(a)
	local id = tonumber(a.asset_id)
	if not id then
		error("asset_id harus angka")
	end
	local parent = a.parent_path and resolve(a.parent_path) or workspace
	local model = InsertService:LoadAsset(id)
	local scripts = {}
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("LuaSourceContainer") then
			table.insert(scripts, d)
		end
	end
	local note
	if a.allow_scripts then
		local bad = 0
		for _, s in ipairs(scripts) do
			if #scanCode(s.Source) > 0 then
				bad = bad + 1
			end
		end
		note = (#scripts > 0) and (#scripts .. " script dipertahankan (" .. bad .. " berpola mencurigakan): PERIKSA isinya sebelum percaya") or "tidak ada script di dalamnya"
	else
		for _, s in ipairs(scripts) do
			s:Destroy()
		end
		note = (#scripts > 0) and (#scripts .. " script di dalam asset dihapus demi keamanan") or "tidak ada script di dalamnya"
	end
	if a.position and #a.position >= 3 then
		pcall(function()
			model:PivotTo(CFrame.new(a.position[1], a.position[2], a.position[3]))
		end)
	end
	local names = {}
	local kids = model:GetChildren()
	for _, c in ipairs(kids) do
		if a.name and #kids == 1 then
			c.Name = a.name
		end
		c.Parent = parent
		table.insert(names, c.Name)
	end
	model:Destroy()
	return "Asset " .. id .. " dimasukkan ke " .. parent:GetFullName() .. ": " .. table.concat(names, ", ") .. " (" .. note .. ")"
end

function impl.search_toolbox(a)
	local ok, pages = pcall(function()
		return InsertService:GetFreeModels(str(a.query) or "", a.page or 0)
	end)
	if not ok then
		error("Pencarian Toolbox tidak tersedia di versi Studio ini: " .. tostring(pages) .. ". Minta user memberi asset id.")
	end
	local results = pages and pages[1] and pages[1].Results or {}
	if #results == 0 then
		return "(tidak ada hasil)"
	end
	local lines = {}
	for i, r in ipairs(results) do
		if i > 20 then
			break
		end
		table.insert(lines, tostring(r.AssetId) .. " | " .. tostring(r.Name) .. " | oleh " .. tostring(r.CreatorName))
	end
	return table.concat(lines, "\n")
end

function impl.terrain(a)
	local T = workspace.Terrain
	local shape = a.shape
	if shape == "clear" then
		T:Clear()
		return "Terrain dibersihkan"
	end
	local mat = getMaterial(a.material)
	local p = vec(a.position, { 0, 0, 0 })
	if shape == "hills" then
		local size = a.size or { 128, 128 }
		local sx = size[1]
		local sz = size[2] or size[1]
		local height = tonumber(a.height) or 20
		local scale = tonumber(a.scale) or 40
		local seed = tonumber(a.seed) or math.random(1, 100000)
		local step = math.max(4, math.ceil(math.max(sx, sz) / 100))
		local nx, nz = math.ceil(sx / step), math.ceil(sz / step)
		local calls = 0
		for ix = 0, nx - 1 do
			for iz = 0, nz - 1 do
				local wx = p.X - sx / 2 + ix * step + step / 2
				local wz = p.Z - sz / 2 + iz * step + step / 2
				local n = math.clamp(math.noise(wx / scale, wz / scale, seed) + 0.5, 0, 1)
				local top = p.Y + n * height + step
				local bottom = p.Y - step * 2
				T:FillBlock(CFrame.new(wx, (top + bottom) / 2, wz), Vector3.new(step, top - bottom, step), mat)
				calls = calls + 1
				if calls % 400 == 0 then
					task.wait()
				end
			end
		end
	elseif shape == "block" then
		T:FillBlock(CFrame.new(p), vec(a.size, { 16, 16, 16 }), mat)
	elseif shape == "ball" then
		T:FillBall(p, a.radius or 8, mat)
	elseif shape == "cylinder" then
		T:FillCylinder(CFrame.new(p), a.height or 8, a.radius or 8, mat)
	else
		error("shape harus block, ball, cylinder, hills, atau clear")
	end
	return "Terrain " .. shape .. " (" .. mat.Name .. ") di " .. string.format("%.0f, %.0f, %.0f", p.X, p.Y, p.Z)
end

local LIGHT_EFFECTS = {
	Atmosphere = true,
	Sky = true,
	BloomEffect = true,
	ColorCorrectionEffect = true,
	SunRaysEffect = true,
	DepthOfFieldEffect = true,
}

function impl.set_lighting(a)
	local L = game:GetService("Lighting")
	applyProps(L, a.properties)
	local created = {}
	for class, props in pairs(a.effects or {}) do
		if not LIGHT_EFFECTS[class] then
			error("Efek tidak didukung: " .. tostring(class))
		end
		local e = L:FindFirstChildOfClass(class)
		if not e then
			e = Instance.new(class)
			e.Name = class
			e.Parent = L
			table.insert(created, class)
		end
		applyProps(e, props)
	end
	return "Lighting diubah" .. ((#created > 0) and (" (efek baru: " .. table.concat(created, ", ") .. ")") or "")
end

function impl.get_output(a)
	local level = a.level or "error"
	if level ~= "error" and level ~= "warning" and level ~= "all" then
		error("level harus error, warning, atau all")
	end
	local limit = math.clamp(a.limit or 30, 1, 100)
	local data = httpGet("/log?level=" .. level .. "&limit=" .. limit)
	local lines = {}
	for _, e in ipairs(data.events or {}) do
		table.insert(lines, "[" .. e.time .. "][" .. e.source .. "][" .. e.level .. "] " .. e.msg)
	end
	if #lines == 0 then
		return "(tidak ada " .. level .. " terbaru di Output)"
	end
	return table.concat(lines, "\n---\n")
end

------------------------------------------------------------------
-- TOOLS BARU v3: create_tree / create_gui
------------------------------------------------------------------
local GUI_DEFAULTS = {
	ScreenGui = { ResetOnSpawn = false, ZIndexBehavior = "Sibling" },
	Frame = { BackgroundColor3 = "$surface", BorderSizePixel = 0 },
	ScrollingFrame = { BackgroundColor3 = "$surface", BorderSizePixel = 0, ScrollBarThickness = 4 },
	TextLabel = { BackgroundTransparency = 1, TextColor3 = "$text", Font = "GothamMedium", TextSize = 16, BorderSizePixel = 0 },
	TextButton = { BackgroundColor3 = "$primary", TextColor3 = "$text", Font = "GothamBold", TextSize = 16, BorderSizePixel = 0 },
	TextBox = { BackgroundColor3 = "$surface2", TextColor3 = "$text", PlaceholderColor3 = "$subtext", Font = "Gotham", TextSize = 16, BorderSizePixel = 0, ClearTextOnFocus = false },
	ImageLabel = { BackgroundTransparency = 1, BorderSizePixel = 0 },
	ImageButton = { BackgroundTransparency = 1, BorderSizePixel = 0 },
}

local function enumByName(enumType, name, what)
	for _, item in ipairs(enumType:GetEnumItems()) do
		if item.Name == name then
			return item
		end
	end
	error("Nilai '" .. tostring(name) .. "' tidak valid untuk " .. what)
end

local function addModifiers(inst, node)
	if node.corner ~= nil then
		local c = Instance.new("UICorner")
		if type(node.corner) == "table" then
			c.CornerRadius = UDim.new(node.corner[1], node.corner[2])
		else
			c.CornerRadius = UDim.new(0, node.corner)
		end
		c.Parent = inst
	end
	if node.stroke then
		local s = Instance.new("UIStroke")
		s.Thickness = node.stroke.thickness or 1
		s.Color = colorFrom(node.stroke.color or "$surface2")
		s.Transparency = node.stroke.transparency or 0
		if not inst:IsA("TextLabel") and not inst:IsA("TextButton") and not inst:IsA("TextBox") then
			s.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		end
		s.Parent = inst
	end
	if node.gradient then
		local g = Instance.new("UIGradient")
		local cols = node.gradient.colors or {}
		local n = #cols
		if n >= 2 then
			local kps = {}
			for k, c in ipairs(cols) do
				table.insert(kps, ColorSequenceKeypoint.new((k - 1) / (n - 1), colorFrom(c)))
			end
			g.Color = ColorSequence.new(kps)
		end
		g.Rotation = node.gradient.rotation or 0
		g.Parent = inst
	end
	if node.padding ~= nil then
		local p = Instance.new("UIPadding")
		local v = node.padding
		if type(v) == "table" then
			p.PaddingLeft = UDim.new(0, v[1] or 0)
			p.PaddingTop = UDim.new(0, v[2] or 0)
			p.PaddingRight = UDim.new(0, v[3] or v[1] or 0)
			p.PaddingBottom = UDim.new(0, v[4] or v[2] or 0)
		else
			p.PaddingLeft = UDim.new(0, v)
			p.PaddingTop = UDim.new(0, v)
			p.PaddingRight = UDim.new(0, v)
			p.PaddingBottom = UDim.new(0, v)
		end
		p.Parent = inst
	end
	if node.list then
		local l = Instance.new("UIListLayout")
		l.Padding = UDim.new(0, node.list.padding or 0)
		l.FillDirection = (node.list.direction == "H") and Enum.FillDirection.Horizontal or Enum.FillDirection.Vertical
		l.SortOrder = Enum.SortOrder.LayoutOrder
		if node.list.halign then
			l.HorizontalAlignment = enumByName(Enum.HorizontalAlignment, node.list.halign, "halign")
		end
		if node.list.valign then
			l.VerticalAlignment = enumByName(Enum.VerticalAlignment, node.list.valign, "valign")
		end
		l.Parent = inst
	end
	if node.grid then
		local g = Instance.new("UIGridLayout")
		local cell = node.grid.cell or { 100, 100 }
		g.CellSize = UDim2.fromOffset(cell[1], cell[2])
		local pad = node.grid.padding or 0
		g.CellPadding = UDim2.fromOffset(pad, pad)
		g.SortOrder = Enum.SortOrder.LayoutOrder
		g.Parent = inst
	end
	if node.aspect then
		local ar = Instance.new("UIAspectRatioConstraint")
		ar.AspectRatio = node.aspect
		ar.Parent = inst
	end
end

local function buildNode(node, parent, ctx)
	if type(node) ~= "table" then
		error("node tree harus objek {class, name, props, children}")
	end
	ctx.count = ctx.count + 1
	if ctx.count > 300 then
		error("Terlalu banyak node (maks 300 per aksi). Pecah jadi beberapa aksi.")
	end
	local class = node.class or node.class_name or (ctx.gui and "Frame" or nil)
	if not class then
		error("setiap node butuh 'class'")
	end
	local inst = Instance.new(class)
	if node.name then
		inst.Name = node.name
	end
	local props = {}
	if ctx.gui and GUI_DEFAULTS[class] then
		for k, v in pairs(GUI_DEFAULTS[class]) do
			props[k] = v
		end
	end
	for k, v in pairs(node.props or node.properties or {}) do
		props[k] = v
	end
	if node.text ~= nil then
		props.Text = node.text
	end
	applyProps(inst, props)
	if ctx.gui then
		addModifiers(inst, node)
	end
	for _, ch in ipairs(node.children or {}) do
		buildNode(ch, inst, ctx)
	end
	inst.Parent = parent -- parent diset terakhir: kalau gagal di tengah, tidak ada sisa di game
	return inst
end

function impl.create_tree(a)
	if type(a.tree) ~= "table" then
		error("'tree' wajib berupa node {class, name, props, children}")
	end
	local parent = resolve(a.parent_path)
	local ctx = { count = 0, gui = false }
	activeTheme = nil
	local root = buildNode(a.tree, parent, ctx)
	return "Tree dibuat: " .. root:GetFullName() .. " (" .. ctx.count .. " objek)"
end

function impl.create_gui(a)
	if type(a.tree) ~= "table" then
		error("'tree' wajib berupa node {class, name, props, children}")
	end
	local parent = resolve(a.parent_path or "StarterGui")
	local theme = a.theme or "dark"
	if type(theme) == "string" then
		activeTheme = THEMES[theme]
		if not activeTheme then
			error("Tema tidak dikenal: " .. theme .. " (dark/light/neon)")
		end
	elseif type(theme) == "table" then
		activeTheme = table.clone(THEMES.dark)
		for k, v in pairs(theme) do
			activeTheme[k] = v
		end
	end
	local ctx = { count = 0, gui = true }
	local ok, res = pcall(buildNode, a.tree, parent, ctx)
	activeTheme = nil
	if not ok then
		error(res, 0)
	end
	return "GUI dibuat: " .. res:GetFullName() .. " (" .. ctx.count .. " objek)"
end

------------------------------------------------------------------
-- TOOLS BARU v3: project_snapshot / verify
------------------------------------------------------------------
function impl.project_snapshot(a)
	local maxChars = math.clamp(tonumber(a.max_chars) or 9000, 2000, 14000)
	local out = {}
	local function add(s)
		table.insert(out, s)
	end
	add("PROJECT SNAPSHOT — " .. game.Name .. " (PlaceId " .. tostring(game.PlaceId) .. ")")

	add("\n[STRUKTUR]")
	for _, svc in ipairs(eachRoot()) do
		local kids = svc:GetChildren()
		add(svc.Name .. " (" .. #kids .. " anak, " .. #svc:GetDescendants() .. " turunan)")
		for i, c in ipairs(kids) do
			if i > 25 then
				add("  ... +" .. (#kids - 25) .. " lagi")
				break
			end
			local n = #c:GetDescendants()
			add("  " .. c.Name .. " [" .. c.ClassName .. "]" .. (n > 0 and (" (" .. n .. ")") or ""))
		end
	end

	add("\n[SCRIPT]")
	local total = 0
	local remotes = {}
	for _, svc in ipairs(eachRoot()) do
		for _, d in ipairs(svc:GetDescendants()) do
			if d:IsA("LuaSourceContainer") then
				total = total + 1
				if total <= 60 then
					local src = d.Source
					local lines = select(2, string.gsub(src, "\n", "\n")) + 1
					local funcs, reqs = {}, {}
					for fn in string.gmatch(src, "function%s+([%w_%.:]+)%s*%(") do
						if #funcs < 8 then
							table.insert(funcs, fn)
						end
					end
					for r in string.gmatch(src, "require%s*%(([^%)]+)%)") do
						if #reqs < 4 then
							table.insert(reqs, (string.gsub(r, "%s+", "")))
						end
					end
					local dis = false
					pcall(function()
						dis = d.Disabled == true
					end)
					add(d:GetFullName() .. " [" .. d.ClassName .. "] " .. lines .. " baris" .. (dis and " DISABLED" or "")
						.. (#funcs > 0 and ("\n    fn: " .. table.concat(funcs, ", ")) or "")
						.. (#reqs > 0 and ("\n    require: " .. table.concat(reqs, ", ")) or ""))
				end
			elseif d:IsA("RemoteEvent") or d:IsA("RemoteFunction") or d:IsA("BindableEvent") or d:IsA("BindableFunction") then
				table.insert(remotes, d:GetFullName() .. " [" .. d.ClassName .. "]")
			end
		end
	end
	if total == 0 then
		add("(belum ada script)")
	elseif total > 60 then
		add("... +" .. (total - 60) .. " script lagi (pakai search_scripts / list_children)")
	end

	add("\n[REMOTE & BINDABLE]")
	if #remotes == 0 then
		add("(tidak ada)")
	else
		for i, r in ipairs(remotes) do
			if i > 40 then
				add("... +" .. (#remotes - 40) .. " lagi")
				break
			end
			add(r)
		end
	end

	local text = table.concat(out, "\n")
	if #text > maxChars then
		text = string.sub(text, 1, maxChars) .. "\n...(snapshot dipotong; pakai list_children / get_script_source untuk detail)"
	end
	return text
end

function impl.verify(a)
	local scopeRoot = a.path and resolve(a.path) or nil
	local function inScope(inst)
		return scopeRoot == nil or inst == scopeRoot or inst:IsDescendantOf(scopeRoot)
	end
	local issues = {}
	local function add(sev, where, msg)
		if #issues < 80 then
			table.insert(issues, sev .. " " .. where .. ": " .. msg)
		end
	end

	local allScripts, remotes = {}, {}
	local unanchored, unanchoredCount = {}, 0
	local scanned = 0
	for _, svc in ipairs(eachRoot()) do
		for _, d in ipairs(svc:GetDescendants()) do
			scanned = scanned + 1
			if d:IsA("LuaSourceContainer") then
				if #allScripts < 500 then
					table.insert(allScripts, { inst = d, src = d.Source })
				end
			elseif d:IsA("RemoteEvent") or d:IsA("RemoteFunction") then
				table.insert(remotes, d)
			elseif scanned < 30000 and inScope(d) and d:IsA("BasePart") and not d:IsA("Terrain")
				and d:IsDescendantOf(workspace) and not d.Anchored then
				local okJ, joints = pcall(function()
					return #d:GetJoints()
				end)
				local inChar = d:FindFirstAncestorOfClass("Tool") or d:FindFirstAncestorOfClass("Accessory")
				local m = d:FindFirstAncestorOfClass("Model")
				if m and m:FindFirstChildOfClass("Humanoid") then
					inChar = true
				end
				if not inChar and not (okJ and joints > 0) then
					unanchoredCount = unanchoredCount + 1
					if #unanchored < 8 then
						table.insert(unanchored, d:GetFullName())
					end
				end
			end
		end
	end

	local checked = 0
	for _, s in ipairs(allScripts) do
		local inst, src = s.inst, s.src
		if inScope(inst) then
			checked = checked + 1
			local where = inst:GetFullName()
			if string.match(src, "^%s*$") then
				add("⚠", where, "script kosong")
			else
				local serr = syntaxError(src)
				if serr then
					add("✘", where, "SYNTAX ERROR: " .. serr)
				end
				if findBare(src, "wait") then
					add("⚠", where, "memakai wait() usang, ganti task.wait()")
				end
				if findBare(src, "spawn") or findBare(src, "delay") then
					add("⚠", where, "memakai spawn()/delay() usang, ganti task.spawn()/task.delay()")
				end
				if string.find(src, "while%s+true%s+do") and not string.find(src, "wait%s*%(") and not string.find(src, ":Wait%(")
					and not string.find(src, "Heartbeat") and not string.find(src, "RenderStepped") and not string.find(src, "Stepped") then
					add("✘", where, "'while true do' tanpa wait/yield (bisa membekukan game)")
				end
				for _, w in ipairs(scanCode(src)) do
					add("⚠", where, "pola mencurigakan: " .. w)
				end
			end
			local dis = false
			pcall(function()
				dis = inst.Disabled == true
			end)
			if dis then
				add("ℹ", where, "script DISABLED")
			end
		end
	end

	for _, r in ipairs(remotes) do
		if inScope(r) then
			local refs = 0
			for _, s in ipairs(allScripts) do
				if string.find(s.src, r.Name, 1, true) then
					refs = refs + 1
				end
			end
			if refs == 0 then
				add("⚠", r:GetFullName(), "[" .. r.ClassName .. "] tidak dirujuk script mana pun (tidak ada handler?)")
			end
		end
	end

	if unanchoredCount > 0 then
		add("⚠", "Workspace", unanchoredCount .. " Part tidak Anchored dan tidak ter-weld (akan jatuh). Contoh: " .. table.concat(unanchored, ", "))
	end

	local header = "Diperiksa: " .. checked .. " script, " .. #remotes .. " remote" .. (canLoad and "" or " (cek syntax tidak tersedia di Studio ini)")
	if #issues == 0 then
		return header .. "\n✔ Tidak ada masalah yang ditemukan."
	end
	return header .. "\n" .. #issues .. " temuan:\n" .. table.concat(issues, "\n")
end

------------------------------------------------------------------
-- TOOLS BARU v3: run_luau / playtest
------------------------------------------------------------------
local function compileFn(src)
	if canLoad then
		local f, err = loadstring(src, "=run_luau")
		if not f then
			error(err, 0)
		end
		return f
	end
	-- cadangan: bungkus ke ModuleScript sementara lalu require
	local m = Instance.new("ModuleScript")
	m.Name = "RS_Temp"
	m.Source = "return function(...)\n" .. src .. "\nend"
	m.Parent = game:GetService("ServerStorage")
	local ok, res = pcall(require, m)
	m:Destroy()
	if not ok then
		error(res, 0)
	end
	return res
end

function impl.run_luau(a)
	local src = str(a.code or a.source)
	if not src or src == "" then
		error("code kosong")
	end
	local serr = syntaxError(src)
	if serr then
		error("Syntax error: " .. serr, 0)
	end
	local timeoutSec = math.clamp(tonumber(a.timeout) or 15, 1, 60)

	local logs = {}
	local conn = LogService.MessageOut:Connect(function(m, t)
		if #logs < 200 then
			local tag = ""
			if t == Enum.MessageType.MessageError then
				tag = "[error] "
			elseif t == Enum.MessageType.MessageWarning then
				tag = "[warn] "
			end
			table.insert(logs, tag .. string.sub(m, 1, 300))
		end
	end)
	forwardState.suppress = true

	local done, okRun, ret = false, false, nil
	local thread = task.spawn(function()
		local okC, fn = pcall(compileFn, src)
		if not okC then
			okRun, ret = false, fn
			done = true
			return
		end
		okRun, ret = pcall(fn)
		done = true
	end)
	local t0 = os.clock()
	while not done and os.clock() - t0 < timeoutSec do
		task.wait(0.1)
	end
	if not done then
		pcall(task.cancel, thread)
	end
	conn:Disconnect()
	forwardState.suppress = false

	local parts = {}
	if #logs > 0 then
		table.insert(parts, "Output:\n" .. table.concat(logs, "\n"))
	end
	if not done then
		error(table.concat(parts, "\n") .. "\n⏱ timeout setelah " .. timeoutSec .. " detik, eksekusi dihentikan", 0)
	elseif not okRun then
		table.insert(parts, "Runtime error: " .. tostring(ret))
		error(table.concat(parts, "\n"), 0)
	end
	if ret ~= nil then
		local okJ, js = pcall(function()
			return HttpService:JSONEncode(ser(ret))
		end)
		table.insert(parts, "Return: " .. (okJ and js or tostring(ret)))
	end
	if #parts == 0 then
		return "Selesai (tanpa output)" .. warnSuffix(src)
	end
	return table.concat(parts, "\n") .. warnSuffix(src)
end

function impl.playtest(a)
	local okS, STS = pcall(function()
		return game:GetService("StudioTestService")
	end)
	if not okS or not STS then
		error("StudioTestService tidak tersedia di versi Studio ini. Jalankan playtest manual (F5) lalu pakai get_output.")
	end
	local duration = math.clamp(tonumber(a.duration) or 10, 3, 120)
	local mode = (a.mode == "run") and "run" or "play"
	local startSeq = (httpGet("/status")).eventSeq or 0

	local okRun, res = pcall(function()
		local args = { rs_duration = duration }
		if mode == "run" then
			return STS:ExecuteRunModeAsync(args)
		end
		return STS:ExecutePlayModeAsync(args)
	end)
	if not okRun then
		error("Playtest gagal berjalan: " .. tostring(res) .. ". Coba jalankan manual (F5) lalu pakai get_output.", 0)
	end
	task.wait(2.5) -- beri waktu forwarder mengirim error terakhir
	local data = httpGet("/log?level=all&after=" .. startSeq .. "&limit=60")
	local lines = {}
	for _, e in ipairs(data.events or {}) do
		table.insert(lines, "[" .. e.source .. "][" .. e.level .. "] " .. e.msg)
	end
	local head = "Playtest (" .. mode .. ", " .. duration .. " dtk) selesai."
	if #lines == 0 then
		return head .. " ✔ Tidak ada error/warning selama playtest."
	end
	return head .. " " .. #lines .. " pesan:\n" .. table.concat(lines, "\n---\n")
end

------------------------------------------------------------------
-- TOOLS BARU v4: bulk_set_properties, replace_in_scripts, script_outline,
--                group_instances, arrange_instances, scatter_instances
------------------------------------------------------------------
local function escapePattern(s)
	return (string.gsub(s, "[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0"))
end

local function instList(paths, what)
	if type(paths) ~= "table" or #paths == 0 then
		error("'" .. what .. "' harus array path (minimal 1)")
	end
	local items = {}
	for _, p in ipairs(paths) do
		table.insert(items, resolve(p))
	end
	return items
end

function impl.bulk_set_properties(a)
	if type(a.properties) ~= "table" or next(a.properties) == nil then
		error("'properties' wajib berisi minimal satu properti")
	end
	if not a.class_name and not a.name_contains and not a.tag then
		error("beri minimal satu filter: class_name, name_contains, atau tag")
	end
	local root = resolve(a.root or "Workspace")
	local limit = math.clamp(tonumber(a.limit) or 200, 1, 1000)
	local nm = a.name_contains and string.lower(tostring(a.name_contains)) or nil
	local changed, failed, capped = 0, 0, false
	local errs = {}
	for _, d in ipairs(root:GetDescendants()) do
		local match = (not a.class_name or d:IsA(a.class_name))
			and (not nm or string.find(string.lower(d.Name), nm, 1, true) ~= nil)
			and (not a.tag or CollectionService:HasTag(d, a.tag))
		if match then
			if changed + failed >= limit then
				capped = true
				break
			end
			local ok, err = pcall(applyProps, d, a.properties)
			if ok then
				changed = changed + 1
			else
				failed = failed + 1
				if #errs < 3 then
					table.insert(errs, d.Name .. ": " .. tostring(err))
				end
			end
		end
	end
	if changed == 0 then
		if failed > 0 then
			error("Semua " .. failed .. " objek gagal diubah. Contoh: " .. table.concat(errs, " | "), 0)
		end
		return "Tidak ada objek yang cocok dengan filter"
	end
	return changed .. " objek diubah"
		.. (failed > 0 and (", " .. failed .. " dilewati (properti tidak berlaku): " .. table.concat(errs, " | ")) or "")
		.. (capped and (" (dibatasi limit " .. limit .. ")") or "")
end

function impl.replace_in_scripts(a)
	local find = str(a.find)
	if not find or find == "" then
		error("'find' kosong")
	end
	local replace = str(a.replace) or ""
	local dry = a.dry_run == true
	local roots
	if a.root then
		roots = { resolve(a.root) }
	else
		roots = eachRoot()
	end
	local pat = escapePattern(find)
	local repl = string.gsub(replace, "%%", "%%%%")
	local report, scripts, occurrences, skipped = {}, 0, 0, 0

	local function process(s)
		if not s:IsA("LuaSourceContainer") then
			return
		end
		local src = s.Source
		local count = select(2, string.gsub(src, pat, ""))
		if count == 0 then
			return
		end
		if scripts >= 100 then
			skipped = skipped + 1
			return
		end
		if dry then
			scripts = scripts + 1
			occurrences = occurrences + count
			table.insert(report, s:GetFullName() .. ": " .. count .. "x")
			return
		end
		local newSrc = string.gsub(src, pat, repl)
		local serr = syntaxError(newSrc)
		if serr then
			table.insert(report, "✘ " .. s:GetFullName() .. ": DILEWATI, hasil akan syntax error (" .. serr .. ")")
			return
		end
		setScriptSource(s, newSrc)
		scripts = scripts + 1
		occurrences = occurrences + count
		table.insert(report, s:GetFullName() .. ": " .. count .. "x diganti")
	end

	for _, r in ipairs(roots) do
		process(r)
		for _, d in ipairs(r:GetDescendants()) do
			process(d)
		end
	end
	if scripts == 0 and #report == 0 then
		return "Tidak ada script yang mengandung teks itu"
	end
	local lines = {}
	for i, l in ipairs(report) do
		if i > 30 then
			table.insert(lines, "... +" .. (#report - 30) .. " lagi")
			break
		end
		table.insert(lines, l)
	end
	return (dry and "DRY-RUN (belum ada yang diubah): " or "") .. occurrences .. " kemunculan di " .. scripts .. " script"
		.. (skipped > 0 and (" (+" .. skipped .. " script dilewati: batas 100)") or "")
		.. "\n" .. table.concat(lines, "\n")
end

function impl.script_outline(a)
	local s = resolve(a.path)
	if not s:IsA("LuaSourceContainer") then
		error(tostring(a.path) .. " bukan script")
	end
	local src = s.Source
	local lineNo = 0
	local funcs, reqs, todos = {}, {}, {}
	local connects = 0
	for line in (src .. "\n"):gmatch("(.-)\n") do
		lineNo = lineNo + 1
		local fn = string.match(line, "^%s*local%s+function%s+([%w_]+)")
			or string.match(line, "^%s*function%s+([%w_%.:]+)")
			or string.match(line, "^%s*local%s+([%w_]+)%s*=%s*function")
		if fn and #funcs < 80 then
			table.insert(funcs, "  " .. lineNo .. ": " .. fn)
		end
		if string.find(line, ":Connect%s*%(") then
			connects = connects + 1
		end
		local rq = string.match(line, "require%s*%(([^%)]+)%)")
		if rq and #reqs < 12 then
			table.insert(reqs, "  " .. lineNo .. ": " .. (string.gsub(rq, "%s+", "")))
		end
		local td = string.match(line, "TODO[:%s]*(.*)")
		if td and #todos < 10 then
			table.insert(todos, "  " .. lineNo .. ": " .. string.sub(td, 1, 80))
		end
	end
	local out = {
		s:GetFullName() .. " [" .. s.ClassName .. "] — " .. lineNo .. " baris",
		"Fungsi (" .. #funcs .. "):",
		(#funcs > 0) and table.concat(funcs, "\n") or "  (tidak ada)",
		"Event :Connect — " .. connects .. " tempat",
	}
	if #reqs > 0 then
		table.insert(out, "require:\n" .. table.concat(reqs, "\n"))
	end
	if #todos > 0 then
		table.insert(out, "TODO:\n" .. table.concat(todos, "\n"))
	end
	table.insert(out, "Tip: get_script_source {path, start_line, end_line} untuk membaca sebagian saja.")
	return table.concat(out, "\n")
end

function impl.group_instances(a)
	local items = instList(a.paths, "paths")
	local class = a.class or "Model"
	if class ~= "Model" and class ~= "Folder" then
		error("class harus Model atau Folder")
	end
	for _, it in ipairs(items) do
		if it == game or it.Parent == game then
			error("Tidak boleh memindahkan service: " .. it.Name)
		end
	end
	local parent = a.parent_path and resolve(a.parent_path) or items[1].Parent
	if not parent then
		error("parent tidak ditemukan")
	end
	local g = Instance.new(class)
	g.Name = a.name or "Group"
	for _, it in ipairs(items) do
		it.Parent = g
	end
	g.Parent = parent
	return "Dikelompokkan " .. #items .. " objek ke " .. g:GetFullName() .. " [" .. class .. "]"
end

function impl.arrange_instances(a)
	local items = {}
	if a.paths then
		items = instList(a.paths, "paths")
	elseif a.parent_path then
		for _, c in ipairs(resolve(a.parent_path):GetChildren()) do
			if c:IsA("PVInstance") then
				table.insert(items, c)
			end
		end
	else
		error("beri 'paths' atau 'parent_path'")
	end
	if #items == 0 then
		error("tidak ada objek (Model/Part) untuk disusun")
	end
	for _, it in ipairs(items) do
		if not it:IsA("PVInstance") then
			error(it:GetFullName() .. " bukan Model/Part")
		end
	end

	local mode = a.mode or "grid"
	local origin = vec(a.origin, { 0, 0, 0 })
	local sp = a.spacing or 8
	local sx, sz
	if type(sp) == "table" then
		sx, sz = sp[1], sp[2] or sp[1]
	else
		sx, sz = sp, sp
	end

	local function place(it, pos, faceTarget)
		if faceTarget then
			it:PivotTo(CFrame.lookAt(pos, Vector3.new(faceTarget.X, pos.Y, faceTarget.Z)))
		else
			it:PivotTo(CFrame.new(pos) * it:GetPivot().Rotation)
		end
	end

	local n = #items
	if mode == "grid" then
		local cols = math.max(1, math.floor(tonumber(a.columns) or math.ceil(math.sqrt(n))))
		for i, it in ipairs(items) do
			local col = (i - 1) % cols
			local row = math.floor((i - 1) / cols)
			place(it, origin + Vector3.new(col * sx, 0, row * sz))
		end
	elseif mode == "line" then
		local axis = string.upper(tostring(a.axis or "X"))
		local dir = Vector3.new(1, 0, 0)
		if axis == "Y" then
			dir = Vector3.new(0, 1, 0)
		elseif axis == "Z" then
			dir = Vector3.new(0, 0, 1)
		end
		for i, it in ipairs(items) do
			place(it, origin + dir * ((i - 1) * sx))
		end
	elseif mode == "circle" then
		local radius = tonumber(a.radius) or math.max(4, n * sx / (2 * math.pi))
		local face = (a.face_center ~= false) and origin or nil
		for i, it in ipairs(items) do
			local ang = (i - 1) / n * math.pi * 2
			place(it, origin + Vector3.new(math.cos(ang) * radius, 0, math.sin(ang) * radius), face)
		end
	elseif mode == "align" then
		local axis = string.upper(tostring(a.axis or "Y"))
		for _, it in ipairs(items) do
			local pv = it:GetPivot().Position
			place(it, Vector3.new(
				(axis == "X") and origin.X or pv.X,
				(axis == "Y") and origin.Y or pv.Y,
				(axis == "Z") and origin.Z or pv.Z
			))
		end
	else
		error("mode harus grid, line, circle, atau align")
	end
	return n .. " objek disusun (" .. mode .. ")"
end

function impl.scatter_instances(a)
	local template = resolve(a.template_path)
	if not template:IsA("Model") and not template:IsA("BasePart") then
		error("template_path harus Model atau Part")
	end
	local parent = a.parent_path and resolve(a.parent_path) or workspace
	local count = math.clamp(math.floor(tonumber(a.count) or 10), 1, 200)
	local center = vec(a.center, { 0, 0, 0 })
	local size = a.size or { 100, 100 }
	local areaX = size[1]
	local areaZ = size[2] or size[1]
	local rng = Random.new(tonumber(a.seed) or os.time())
	local align = a.align_to_ground ~= false
	local rotate = a.random_rotation ~= false
	local srange = a.scale_range
	local minDist = tonumber(a.min_distance) or 0

	local folder = Instance.new("Folder")
	folder.Name = a.name or (template.Name .. "_scatter")
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { folder, template }

	local placed, made, attempts, noGround = {}, 0, 0, 0
	while made < count and attempts < count * 25 do
		attempts = attempts + 1
		local x = center.X + (rng:NextNumber() - 0.5) * areaX
		local z = center.Z + (rng:NextNumber() - 0.5) * areaZ
		local close = false
		if minDist > 0 then
			for _, p in ipairs(placed) do
				local dx, dz = p.X - x, p.Z - z
				if dx * dx + dz * dz < minDist * minDist then
					close = true
					break
				end
			end
		end
		if not close then
			local y = center.Y
			local ok = true
			if align then
				local hit = workspace:Raycast(Vector3.new(x, center.Y + 500, z), Vector3.new(0, -1000, 0), params)
				if hit then
					y = hit.Position.Y
				else
					ok = false
					noGround = noGround + 1
				end
			end
			if ok then
				local c = template:Clone()
				if type(srange) == "table" and tonumber(srange[1]) and tonumber(srange[2]) then
					local s = rng:NextNumber(srange[1], srange[2])
					if c:IsA("Model") then
						c:ScaleTo(s)
					else
						c.Size = c.Size * s
					end
				end
				local rot = rotate and CFrame.Angles(0, rng:NextNumber(0, math.pi * 2), 0) or CFrame.new()
				c:PivotTo(CFrame.new(x, y, z) * rot)
				if align then
					local bcf, bsz
					if c:IsA("Model") then
						bcf, bsz = c:GetBoundingBox()
					else
						bcf, bsz = c.CFrame, c.Size
					end
					local bottom = bcf.Position.Y - bsz.Y / 2
					c:PivotTo(c:GetPivot() + Vector3.new(0, y - bottom, 0))
				end
				c.Parent = folder
				table.insert(placed, Vector3.new(x, y, z))
				made = made + 1
			end
		end
	end
	if made == 0 then
		folder:Destroy()
		error("Tidak ada titik valid" .. (align and " (raycast tidak mengenai tanah: pastikan ada Part/Terrain di area itu, atau set align_to_ground=false)" or ""), 0)
	end
	folder.Parent = parent
	return made .. "/" .. count .. " '" .. template.Name .. "' disebar ke " .. folder:GetFullName()
		.. (noGround > 0 and (" (" .. noGround .. " titik tanpa tanah dilewati)") or "")
end

------------------------------------------------------------------
-- DIFF & PREVIEW (untuk mode review)
------------------------------------------------------------------
local function esc(s)
	return (tostring(s):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))
end

local function splitLines(s)
	local t = {}
	for line in ((s or "") .. "\n"):gmatch("(.-)\n") do
		t[#t + 1] = line
	end
	return t
end

local function diffLines(a, b)
	local n, m = #a, #b
	if n * m > 400000 then
		return nil
	end
	local dp = {}
	for i = 0, n do
		dp[i] = table.create(m + 1, 0)
	end
	for i = n - 1, 0, -1 do
		for j = m - 1, 0, -1 do
			if a[i + 1] == b[j + 1] then
				dp[i][j] = dp[i + 1][j + 1] + 1
			else
				dp[i][j] = math.max(dp[i + 1][j], dp[i][j + 1])
			end
		end
	end
	local ops = {}
	local i, j = 0, 0
	while i < n and j < m do
		if a[i + 1] == b[j + 1] then
			ops[#ops + 1] = { " ", a[i + 1] }
			i = i + 1
			j = j + 1
		elseif dp[i + 1][j] >= dp[i][j + 1] then
			ops[#ops + 1] = { "-", a[i + 1] }
			i = i + 1
		else
			ops[#ops + 1] = { "+", b[j + 1] }
			j = j + 1
		end
	end
	while i < n do
		ops[#ops + 1] = { "-", a[i + 1] }
		i = i + 1
	end
	while j < m do
		ops[#ops + 1] = { "+", b[j + 1] }
		j = j + 1
	end
	return ops
end

local GREEN, RED, GREY = "#7ee787", "#ff7b72", "#8b949e"

local function renderDiff(old, new)
	local a, b = splitLines(old), splitLines(new)
	local ops = diffLines(a, b)
	if not ops then
		return "(script besar, diff dilewati: " .. #a .. " → " .. #b .. " baris)"
	end
	local show, adds, dels = {}, 0, 0
	for i, op in ipairs(ops) do
		if op[1] ~= " " then
			if op[1] == "+" then
				adds = adds + 1
			else
				dels = dels + 1
			end
			for k = math.max(1, i - 2), math.min(#ops, i + 2) do
				show[k] = true
			end
		end
	end
	if adds + dels == 0 then
		return "(tidak ada perubahan)"
	end
	local lines = { "+" .. adds .. " / -" .. dels .. " baris" }
	local last, shown = 0, 0
	for i, op in ipairs(ops) do
		if show[i] then
			if last ~= 0 and i ~= last + 1 then
				lines[#lines + 1] = "…"
			end
			shown = shown + 1
			if shown > 300 then
				lines[#lines + 1] = "... (diff dipotong)"
				break
			end
			local color = (op[1] == "+") and GREEN or ((op[1] == "-") and RED or GREY)
			lines[#lines + 1] = '<font color="' .. color .. '">' .. op[1] .. " " .. esc(op[2]) .. "</font>"
			last = i
		end
	end
	return table.concat(lines, "\n")
end

local function warnBlock(src)
	local w = scanCode(src)
	if #w == 0 then
		return ""
	end
	return '\n<font color="' .. RED .. '"><b>⚠ Pola mencurigakan:</b> ' .. esc(table.concat(w, "; ")) .. "</font>"
end

local function codePreview(src, limit)
	local lines = {}
	local sl = splitLines(src or "")
	for i = 1, math.min(#sl, limit) do
		lines[#lines + 1] = '<font color="' .. GREEN .. '">+ ' .. esc(sl[i]) .. "</font>"
	end
	if #sl > limit then
		lines[#lines + 1] = "... (+" .. (#sl - limit) .. " baris lagi)"
	end
	return table.concat(lines, "\n")
end

local function describe(a)
	local t = tostring(a.tool)
	if t == "create_script" then
		local src = str(a.source) or ""
		return "<b>＋ " .. esc(a.script_type) .. "</b> " .. esc(a.parent_path) .. "." .. esc(a.name) .. "\n" .. codePreview(src, 60) .. warnBlock(src)
	elseif t == "run_luau" then
		local src = str(a.code or a.source) or ""
		return '<font color="' .. RED .. '"><b>▶ run_luau</b> (menjalankan kode di Studio)</font>\n' .. codePreview(src, 60) .. warnBlock(src)
	elseif t == "edit_script" then
		local header = "<b>✎ edit_script</b> " .. esc(a.path)
		local ok, inst = pcall(resolve, a.path)
		if not ok or not inst:IsA("LuaSourceContainer") then
			return header .. '\n<font color="' .. RED .. '">script tidak ditemukan</font>'
		end
		local ok2, newSrc = pcall(computeEdit, inst, a)
		if not ok2 then
			return header .. '\n<font color="' .. RED .. '">' .. esc(newSrc) .. "</font>"
		end
		return header .. "\n" .. renderDiff(inst.Source, newSrc) .. warnBlock(newSrc)
	elseif t == "delete_instance" then
		local ok, inst = pcall(resolve, a.path)
		if not ok then
			return "<b>🗑 delete_instance</b> " .. esc(a.path) .. " (tidak ditemukan)"
		end
		local desc = inst:GetDescendants()
		local sc = 0
		for _, d in ipairs(desc) do
			if d:IsA("LuaSourceContainer") then
				sc = sc + 1
			end
		end
		return '<font color="' .. RED .. '"><b>🗑 HAPUS</b> ' .. esc(a.path) .. " [" .. inst.ClassName .. "] — " .. #desc .. " turunan, " .. sc .. " script</font>"
	elseif t == "insert_asset" then
		return "<b>⬇ insert_asset</b> id " .. esc(a.asset_id) .. " → " .. esc(a.parent_path or "Workspace")
			.. (a.allow_scripts and ('\n<font color="' .. RED .. '">script di asset DIPERTAHANKAN (allow_scripts)</font>') or "\nscript di asset akan dihapus")
	elseif t == "replace_in_scripts" then
		local f, r = str(a.find) or "", str(a.replace) or ""
		return (a.dry_run == true and "<b>🔍 replace_in_scripts</b> (dry-run)" or ('<font color="' .. RED .. '"><b>⇄ replace_in_scripts</b> (MENGUBAH banyak script)</font>'))
			.. "\n<font color=\"" .. RED .. "\">- " .. esc(f) .. "</font>\n<font color=\"" .. GREEN .. "\">+ " .. esc(r) .. "</font>"
			.. "\nlingkup: " .. esc(a.root or "semua script")
	end
	local copy = {}
	for k, v in pairs(a) do
		if k ~= "tool" then
			copy[k] = v
		end
	end
	local ok, js = pcall(function()
		return HttpService:JSONEncode(copy)
	end)
	js = ok and js or "?"
	if #js > 160 then
		js = string.sub(js, 1, 160) .. "…"
	end
	return "<b>" .. esc(t) .. "</b> " .. esc(js)
end

local RISKY = { create_script = true, edit_script = true, delete_instance = true, insert_asset = true, run_luau = true, replace_in_scripts = true }
local READ_ONLY = {
	list_children = true, get_properties = true, get_selection = true, get_script_source = true,
	get_output = true, search_scripts = true, search_toolbox = true,
	project_snapshot = true, verify = true, find_instances = true, script_outline = true,
	dump_scripts = true,
}

local function isRisky(a)
	if a.tool == "replace_in_scripts" and a.dry_run == true then
		return false
	end
	return RISKY[a.tool] == true
end

local function isReadOnly(a)
	return READ_ONLY[a.tool] == true or (a.tool == "replace_in_scripts" and a.dry_run == true)
end

------------------------------------------------------------------
-- UI v4
------------------------------------------------------------------
local TweenService = game:GetService("TweenService")

local C = {
	bg = Color3.fromRGB(20, 21, 26),
	panel = Color3.fromRGB(28, 30, 38),
	card = Color3.fromRGB(35, 38, 50),
	border = Color3.fromRGB(46, 50, 66),
	accent = Color3.fromRGB(76, 141, 255),
	green = Color3.fromRGB(61, 220, 132),
	red = Color3.fromRGB(255, 92, 92),
	amber = Color3.fromRGB(255, 176, 32),
	text = Color3.fromRGB(232, 234, 242),
	sub = Color3.fromRGB(139, 145, 167),
}
local WHITE = Color3.new(1, 1, 1)
local KIND_COLOR = { info = C.accent, ok = C.green, err = C.red, warn = C.amber }
local KIND_ICON = { info = "●", ok = "✔", err = "✘", warn = "⚠" }

local function new(class, props, parent)
	local o = Instance.new(class)
	for k, v in pairs(props) do
		o[k] = v
	end
	o.Parent = parent
	return o
end

local function corner(inst, r)
	return new("UICorner", { CornerRadius = UDim.new(0, r) }, inst)
end

local function stroke(inst, color, th)
	return new("UIStroke", { Color = color, Thickness = th or 1, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, inst)
end

local function label(parent, props)
	local p = {
		BackgroundTransparency = 1, Font = Enum.Font.Gotham, TextSize = 12, TextColor3 = C.text,
		TextXAlignment = Enum.TextXAlignment.Left, Text = "",
	}
	for k, v in pairs(props) do
		p[k] = v
	end
	return new("TextLabel", p, parent)
end

local function firstLine(s)
	return (string.match(tostring(s), "^[^\n]*"))
end

local toolbar = plugin:CreateToolbar("RobloxScripter")
-- Ikon tombol toolbar: upload branding/RobloxScripter_logo.png ke Roblox (Creator Hub > Asset),
-- lalu ganti angka 0 di bawah dengan Image ID-nya, contoh "rbxassetid://123456789".
local TOOLBAR_ICON = "rbxassetid://0"
local btn = toolbar:CreateButton("RobloxScripter", "Hubungkan Studio ke ekstensi browser", TOOLBAR_ICON)
btn.ClickableWhenViewportHidden = true

local widget = plugin:CreateDockWidgetPluginGui(
	"RobloxScripterBridge",
	DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Right, false, false, 380, 520, 300, 260)
)
widget.Title = "RobloxScripter v4"
widget.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

local root = new("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = C.bg, BorderSizePixel = 0 }, widget)

-- header --------------------------------------------------------
local header = new("Frame", { Size = UDim2.new(1, 0, 0, 46), BackgroundColor3 = WHITE, BorderSizePixel = 0 }, root)
new("UIGradient", {
	Color = ColorSequence.new(Color3.fromRGB(34, 37, 48), Color3.fromRGB(26, 28, 36)),
	Rotation = 90,
}, header)
local statusDot = new("Frame", {
	Position = UDim2.fromOffset(14, 17), Size = UDim2.fromOffset(12, 12), BackgroundColor3 = C.red, BorderSizePixel = 0,
}, header)
corner(statusDot, 6)
label(header, {
	Position = UDim2.fromOffset(36, 6), Size = UDim2.new(1, -110, 0, 18), Text = "RobloxScripter",
	Font = Enum.Font.GothamBold, TextSize = 15,
})
local statusLabel = label(header, {
	Position = UDim2.fromOffset(36, 25), Size = UDim2.new(1, -110, 0, 14), Text = "Belum terhubung",
	TextSize = 11, TextColor3 = C.sub, TextTruncate = Enum.TextTruncate.AtEnd,
})
local badge = label(header, {
	AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -12, 0.5, 0), Size = UDim2.fromOffset(52, 22),
	BackgroundTransparency = 0, BackgroundColor3 = C.accent, Text = "v4 · 32", Font = Enum.Font.GothamBold,
	TextSize = 11, TextColor3 = WHITE, TextXAlignment = Enum.TextXAlignment.Center,
})
corner(badge, 11)

local function setStatus(text, ok, pending)
	statusLabel.Text = text
	statusDot.BackgroundColor3 = pending and C.amber or (ok and C.green or C.red)
end

-- token ---------------------------------------------------------
local hasToken = (plugin:GetSetting("RS_Token") or "") ~= ""
local tokenBox = new("TextBox", {
	Position = UDim2.fromOffset(10, 54), Size = UDim2.new(1, -20, 0, 28), BackgroundColor3 = C.card, BorderSizePixel = 0,
	TextColor3 = C.text, PlaceholderColor3 = C.sub, Font = Enum.Font.Code, TextSize = 12, Text = "",
	ClearTextOnFocus = false, TextXAlignment = Enum.TextXAlignment.Left,
	PlaceholderText = hasToken and "🔑 token tersimpan — tempel token baru untuk mengganti" or "🔑 tempel TOKEN dari console server.js lalu Enter",
}, root)
corner(tokenBox, 8)
new("UIPadding", { PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 10) }, tokenBox)
local tokenStroke = stroke(tokenBox, hasToken and C.green or C.border, 1)

-- kontrol: mode review (segmented) + rollback (switch) ------------
local MODES = { { "risky", "🛡 Risiko" }, { "all", "🔒 Semua" }, { "off", "⚠ Mati" } }
local reviewMode = plugin:GetSetting("RS_ReviewMode")
if reviewMode ~= "risky" and reviewMode ~= "all" and reviewMode ~= "off" then
	reviewMode = "risky"
end

local seg = new("Frame", {
	Position = UDim2.fromOffset(10, 90), Size = UDim2.new(0.62, -10, 0, 30), BackgroundColor3 = C.card, BorderSizePixel = 0,
}, root)
corner(seg, 8)
new("UIPadding", {
	PaddingLeft = UDim.new(0, 3), PaddingRight = UDim.new(0, 3), PaddingTop = UDim.new(0, 3), PaddingBottom = UDim.new(0, 3),
}, seg)
new("UIListLayout", {
	FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 2), SortOrder = Enum.SortOrder.LayoutOrder,
}, seg)
local segBtns = {}
local function refreshMode()
	for key, b in pairs(segBtns) do
		local sel = key == reviewMode
		b.BackgroundTransparency = sel and 0 or 1
		b.BackgroundColor3 = (key == "off") and C.amber or C.accent
		b.TextColor3 = sel and WHITE or C.sub
	end
end
for i, m in ipairs(MODES) do
	local b = new("TextButton", {
		Size = UDim2.new(1 / 3, -2, 1, 0), BackgroundTransparency = 1, BorderSizePixel = 0, AutoButtonColor = false,
		Text = m[2], Font = Enum.Font.GothamMedium, TextSize = 11, TextColor3 = C.sub, LayoutOrder = i,
	}, seg)
	corner(b, 6)
	segBtns[m[1]] = b
	b.MouseButton1Click:Connect(function()
		reviewMode = m[1]
		plugin:SetSetting("RS_ReviewMode", reviewMode)
		refreshMode()
	end)
end
refreshMode()

local atomicOn = plugin:GetSetting("RS_Atomic") ~= false
local rb = new("TextButton", {
	Position = UDim2.new(0.62, 4, 0, 90), Size = UDim2.new(0.38, -14, 0, 30), BackgroundColor3 = C.card,
	BorderSizePixel = 0, AutoButtonColor = false, Text = "",
}, root)
corner(rb, 8)
label(rb, { Position = UDim2.fromOffset(10, 0), Size = UDim2.new(1, -56, 1, 0), Text = "↩ Rollback", TextSize = 11, Font = Enum.Font.GothamMedium })
local rbTrack = new("Frame", {
	AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -8, 0.5, 0), Size = UDim2.fromOffset(34, 18),
	BackgroundColor3 = C.border, BorderSizePixel = 0,
}, rb)
corner(rbTrack, 9)
local rbKnob = new("Frame", { Size = UDim2.fromOffset(14, 14), Position = UDim2.fromOffset(2, 2), BackgroundColor3 = WHITE, BorderSizePixel = 0 }, rbTrack)
corner(rbKnob, 7)
local function refreshAtomic()
	local info = TweenInfo.new(0.12)
	TweenService:Create(rbKnob, info, { Position = atomicOn and UDim2.fromOffset(18, 2) or UDim2.fromOffset(2, 2) }):Play()
	TweenService:Create(rbTrack, info, { BackgroundColor3 = atomicOn and C.green or C.border }):Play()
end
rbKnob.Position = atomicOn and UDim2.fromOffset(18, 2) or UDim2.fromOffset(2, 2)
rbTrack.BackgroundColor3 = atomicOn and C.green or C.border
rb.MouseButton1Click:Connect(function()
	atomicOn = not atomicOn
	plugin:SetSetting("RS_Atomic", atomicOn)
	refreshAtomic()
end)

-- statistik + hapus log -------------------------------------------
local stats = { batches = 0, ok = 0, fail = 0 }
local statsLabel = label(root, {
	Position = UDim2.fromOffset(12, 128), Size = UDim2.new(1, -110, 0, 22), TextSize = 11, TextColor3 = C.sub, Text = "",
})
local function refreshStats()
	statsLabel.Text = string.format("%d batch   ·   ✔ %d   ·   ✘ %d", stats.batches, stats.ok, stats.fail)
end
refreshStats()
local clearBtn = new("TextButton", {
	AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -10, 0, 128), Size = UDim2.fromOffset(86, 22),
	BackgroundColor3 = C.card, BorderSizePixel = 0, Text = "Hapus log", Font = Enum.Font.GothamMedium,
	TextSize = 11, TextColor3 = C.sub, AutoButtonColor = true,
}, root)
corner(clearBtn, 6)

-- log -----------------------------------------------------------
local LOG_TOP = 156
local logFrame = new("ScrollingFrame", {
	Position = UDim2.fromOffset(0, LOG_TOP), Size = UDim2.new(1, 0, 1, -LOG_TOP), BackgroundTransparency = 1,
	BorderSizePixel = 0, ScrollBarThickness = 5, ScrollBarImageColor3 = C.border, CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y,
}, root)
new("UIListLayout", { Padding = UDim.new(0, 5), SortOrder = Enum.SortOrder.LayoutOrder }, logFrame)
new("UIPadding", {
	PaddingTop = UDim.new(0, 2), PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 12), PaddingBottom = UDim.new(0, 10),
}, logFrame)

local emptyLabel = label(logFrame, {
	Size = UDim2.new(1, 0, 0, 60), Text = "Menunggu perintah dari ekstensi…\nBuka situs AI dan minta sesuatu.",
	TextColor3 = C.sub, TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Center, LayoutOrder = 0,
})

local order = 0
local logCards = {}

local function log(text, kind, sub)
	kind = kind or "info"
	order = order + 1
	emptyLabel.Visible = false
	local card = new("Frame", {
		Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y, BackgroundColor3 = C.card,
		BorderSizePixel = 0, LayoutOrder = order,
	}, logFrame)
	corner(card, 6)
	new("Frame", { Size = UDim2.new(0, 3, 1, 0), BackgroundColor3 = KIND_COLOR[kind], BorderSizePixel = 0 }, card)
	local msg = esc(text)
	if sub and sub ~= "" then
		msg = msg .. '\n<font color="#8B91A7" size="11">' .. esc(string.sub(sub, 1, 220)) .. "</font>"
	end
	local lbl = label(card, {
		Position = UDim2.fromOffset(12, 0), Size = UDim2.new(1, -18, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
		TextWrapped = true, RichText = true,
		Text = '<font color="#8B91A7" size="10">' .. os.date("%H:%M:%S") .. "</font>  <font color=\"#"
			.. KIND_COLOR[kind]:ToHex() .. '">' .. KIND_ICON[kind] .. "</font> " .. msg,
	})
	new("UIPadding", { PaddingTop = UDim.new(0, 6), PaddingBottom = UDim.new(0, 6) }, lbl)
	table.insert(logCards, card)
	if #logCards > 100 then
		table.remove(logCards, 1):Destroy()
	end
	task.delay(0.05, function()
		logFrame.CanvasPosition = Vector2.new(0, 1e6)
	end)
end

clearBtn.MouseButton1Click:Connect(function()
	for _, c in ipairs(logCards) do
		c:Destroy()
	end
	logCards = {}
	stats = { batches = 0, ok = 0, fail = 0 }
	refreshStats()
	emptyLabel.Visible = true
end)

-- panel review ----------------------------------------------------
local reviewFrame = new("Frame", {
	Position = UDim2.fromOffset(0, 46), Size = UDim2.new(1, 0, 1, -46), BackgroundColor3 = C.bg, BorderSizePixel = 0,
	Visible = false, ZIndex = 10,
}, root)
local reviewTitle = label(reviewFrame, {
	Position = UDim2.fromOffset(14, 8), Size = UDim2.new(1, -28, 0, 20), Text = "Tinjau perubahan",
	Font = Enum.Font.GothamBold, TextSize = 15, ZIndex = 10,
})
local reviewSub = label(reviewFrame, {
	Position = UDim2.fromOffset(14, 28), Size = UDim2.new(1, -28, 0, 16), Text = "", TextSize = 11,
	TextColor3 = C.sub, RichText = true, ZIndex = 10,
})
local reviewScroll = new("ScrollingFrame", {
	Position = UDim2.fromOffset(0, 50), Size = UDim2.new(1, 0, 1, -112), BackgroundTransparency = 1, BorderSizePixel = 0,
	ScrollBarThickness = 5, ScrollBarImageColor3 = C.border, CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y, ZIndex = 10,
}, reviewFrame)
new("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }, reviewScroll)
new("UIPadding", { PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 12), PaddingBottom = UDim.new(0, 8) }, reviewScroll)

local reviewFooter = new("Frame", {
	AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 0, 1, 0), Size = UDim2.new(1, 0, 0, 58),
	BackgroundColor3 = C.panel, BorderSizePixel = 0, ZIndex = 10,
}, reviewFrame)
local approveBtn = new("TextButton", {
	Position = UDim2.fromOffset(10, 10), Size = UDim2.new(0.6, -14, 0, 38), BackgroundColor3 = Color3.fromRGB(35, 150, 80),
	BorderSizePixel = 0, TextColor3 = WHITE, Font = Enum.Font.GothamBold, TextSize = 13, Text = "✔  Terapkan", ZIndex = 10,
}, reviewFooter)
corner(approveBtn, 10)
local rejectBtn = new("TextButton", {
	Position = UDim2.new(0.6, 0, 0, 10), Size = UDim2.new(0.4, -10, 0, 38), BackgroundColor3 = Color3.fromRGB(150, 50, 55),
	BorderSizePixel = 0, TextColor3 = WHITE, Font = Enum.Font.GothamBold, TextSize = 13, Text = "✘  Tolak", ZIndex = 10,
}, reviewFooter)
corner(rejectBtn, 10)

local function actionColor(a)
	local t = a.tool
	if t == "delete_instance" or t == "run_luau" or (t == "replace_in_scripts" and a.dry_run ~= true)
		or (t == "insert_asset" and a.allow_scripts) then
		return C.red
	end
	if t == "create_script" or t == "edit_script" then
		return C.amber
	end
	return C.accent
end

local function sourceOf(a)
	return str(a.source) or str(a.code) or str(a.replace) or ""
end

local function addReviewCard(i, a)
	local color = actionColor(a)
	local card = new("Frame", {
		Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y, BackgroundColor3 = C.card, BorderSizePixel = 0,
		LayoutOrder = i, ZIndex = 10,
	}, reviewScroll)
	corner(card, 8)
	new("Frame", { Size = UDim2.new(0, 3, 1, 0), BackgroundColor3 = color, BorderSizePixel = 0, ZIndex = 10 }, card)
	local inner = new("Frame", {
		Position = UDim2.fromOffset(3, 0), Size = UDim2.new(1, -3, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
		BackgroundTransparency = 1, ZIndex = 10,
	}, card)
	new("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder }, inner)
	new("UIPadding", {
		PaddingTop = UDim.new(0, 8), PaddingBottom = UDim.new(0, 8), PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 8),
	}, inner)
	label(inner, {
		Size = UDim2.new(1, 0, 0, 16), Text = i .. "  ·  " .. tostring(a.tool), Font = Enum.Font.GothamBold, TextSize = 12,
		TextColor3 = color, LayoutOrder = 1, ZIndex = 10,
	})
	label(inner, {
		Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y, Font = Enum.Font.Code, TextSize = 12,
		TextWrapped = true, RichText = true, TextYAlignment = Enum.TextYAlignment.Top, Text = describe(a),
		LayoutOrder = 2, ZIndex = 10,
	})
end

local decisionEvent = nil

local function askReview(batch)
	for _, c in ipairs(reviewScroll:GetChildren()) do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	local suspicious = 0
	for i, a in ipairs(batch.actions) do
		addReviewCard(i, a)
		if #scanCode(sourceOf(a)) > 0 then
			suspicious = suspicious + 1
		end
	end
	reviewTitle.Text = "Tinjau perubahan  #" .. batch.id
	reviewSub.Text = #batch.actions .. " aksi" .. ((suspicious > 0)
		and ('   ·   <font color="#FF5C5C">⚠ ' .. suspicious .. " berpola mencurigakan</font>") or "")
	reviewScroll.CanvasPosition = Vector2.new(0, 0)
	reviewFrame.Visible = true
	setStatus("Menunggu persetujuanmu (#" .. batch.id .. ")", true, true)

	local ev = Instance.new("BindableEvent")
	decisionEvent = ev
	local timer = task.delay(600, function()
		ev:Fire(false, "waktu persetujuan habis")
	end)
	local approved, why = ev.Event:Wait()
	pcall(task.cancel, timer)
	decisionEvent = nil
	ev:Destroy()
	reviewFrame.Visible = false
	return approved, why
end

approveBtn.MouseButton1Click:Connect(function()
	if decisionEvent then
		decisionEvent:Fire(true)
	end
end)
rejectBtn.MouseButton1Click:Connect(function()
	if decisionEvent then
		decisionEvent:Fire(false, "ditolak user")
	end
end)

local function needsReview(batch)
	if reviewMode == "off" then
		return false
	end
	local allRead, anyRisky = true, false
	for _, a in ipairs(batch.actions) do
		if not isReadOnly(a) then
			allRead = false
		end
		if isRisky(a) then
			anyRisky = true
		end
	end
	if allRead then
		return false
	end
	return reviewMode == "all" or anyRisky
end

------------------------------------------------------------------
-- EKSEKUSI BATCH & LOOP POLLING
------------------------------------------------------------------
local function postResults(id, results, execSecs)
	local ok, err = pcall(function()
		return request("/results", "POST", { id = id, results = results, exec = execSecs })
	end)
	if not ok then
		log("Gagal kirim hasil ke server", "err", tostring(err))
	end
end

local function executeInner(batch)
	local names = {}
	for _, a in ipairs(batch.actions) do
		table.insert(names, tostring(a.tool))
	end
	local quiet = batch.quiet == true
	if not quiet then
		log("#" .. batch.id .. " masuk — " .. #batch.actions .. " aksi", "info", table.concat(names, ", "))
		stats.batches = stats.batches + 1
		refreshStats()
	end
	local results = {}

	if needsReview(batch) then
		local approved, why = askReview(batch)
		if not approved then
			for _, a in ipairs(batch.actions) do
				table.insert(results, {
					tool = tostring(a.tool),
					ok = false,
					output = "DITOLAK oleh user di Studio (" .. tostring(why) .. "). Jangan ulangi persis sama: tanya user atau ubah pendekatan.",
				})
			end
			stats.fail = stats.fail + #results
			refreshStats()
			log("#" .. batch.id .. " ditolak", "warn", tostring(why))
			postResults(batch.id, results)
			return
		end
	end

	if not quiet then
		setStatus("Menjalankan #" .. batch.id .. "…", true, true)
	end
	local tRun = os.clock()
	local rec = ChangeHistoryService:TryBeginRecording("RobloxScripter #" .. batch.id)
	local failed = false
	for _, a in ipairs(batch.actions) do
		if failed then
			table.insert(results, { tool = tostring(a.tool), ok = false, output = "dilewati karena aksi sebelumnya gagal" })
		else
			local fn = impl[a.tool]
			local ok, out = pcall(function()
				if not fn then
					error("Tool tidak dikenal: " .. tostring(a.tool))
				end
				return fn(a)
			end)
			table.insert(results, { tool = tostring(a.tool), ok = ok, output = tostring(out) })
			local where = a.path or a.parent_path or a.name
			if type(where) == "table" then
				where = table.concat(where, ".")
			end
			if not quiet or not ok then
				log(tostring(a.tool) .. (where and (" → " .. tostring(where)) or ""), ok and "ok" or "err", firstLine(out))
			end
			if not ok then
				failed = true
			end
		end
	end

	if rec then
		if failed and atomicOn then
			-- batch atomik: ada yang gagal -> batalkan semua perubahan batch ini
			ChangeHistoryService:FinishRecording(rec, Enum.FinishRecordingOperation.Cancel)
			for _, r in ipairs(results) do
				if r.ok and not READ_ONLY[r.tool] then
					r.output = r.output .. "\n↩ DIBATALKAN (rollback): ada aksi lain di batch ini yang gagal. Kalau masih ada sisa, tekan Ctrl+Z."
				end
			end
			log("#" .. batch.id .. " di-rollback", "warn", "ada aksi yang gagal")
		else
			ChangeHistoryService:FinishRecording(rec, Enum.FinishRecordingOperation.Commit)
		end
	end
	if not quiet then
		for _, r in ipairs(results) do
			if r.ok then
				stats.ok = stats.ok + 1
			else
				stats.fail = stats.fail + 1
			end
		end
		refreshStats()
	end
	local execSecs = os.clock() - tRun
	if not quiet then
		log("#" .. batch.id .. " selesai", failed and "warn" or "ok", string.format("%.2f dtk", execSecs))
	end
	postResults(batch.id, results, execSecs)
end

local function execute(batch)
	-- keep-alive selama eksekusi/review panjang (playtest, run_luau, menunggu persetujuan)
	local alive = true
	task.spawn(function()
		while alive do
			pcall(request, "/ping?sid=" .. SID, "GET")
			task.wait(8)
		end
	end)
	local ok, err = pcall(executeInner, batch)
	alive = false
	if not ok then
		error(err, 0)
	end
end

local session = 0
local start -- didefinisikan di bawah (dipakai kolom token)

tokenBox.FocusLost:Connect(function()
	local tok = string.gsub(tokenBox.Text, "%s", "")
	tokenBox.Text = ""
	if tok == "" then
		return
	end
	if string.match(tok, "^%x+$") and #tok >= 24 then
		plugin:SetSetting("RS_Token", tok)
		tokenBox.PlaceholderText = "🔑 token tersimpan — tempel token baru untuk mengganti"
		tokenStroke.Color = C.green
		if widget.Enabled then
			start()
		end
	else
		tokenBox.PlaceholderText = "✘ token tidak valid — salin persis dari console server.js"
		tokenStroke.Color = C.red
	end
end)

-- Pairing otomatis: server hanya memberi token selama jendela 60 detik yang dibuka dari dashboard.
local function tryPair()
	local ok, res = pcall(function()
		return HttpService:RequestAsync({
			Url = BASE .. "/pair/claim", Method = "POST",
			Headers = { ["Content-Type"] = "application/json" }, Body = "{}",
		})
	end)
	if not ok or not res.Success then
		return false
	end
	local okj, data = pcall(function()
		return HttpService:JSONDecode(res.Body)
	end)
	if okj and type(data) == "table" and type(data.token) == "string" and #data.token >= 24 then
		plugin:SetSetting("RS_Token", data.token)
		tokenBox.PlaceholderText = "🔑 token tersimpan (pairing otomatis)"
		tokenStroke.Color = C.green
		log("Pairing otomatis berhasil", "ok")
		return true
	end
	return false
end

local function loop(my)
	local warned = false
	while my == session do
		local tok = plugin:GetSetting("RS_Token")
		if not tok or tok == "" then
			setStatus("Menunggu pairing — klik Hubungkan di dashboard (127.0.0.1:3030)", false)
			tryPair()
			task.wait(2)
		else
			local ok, res = pcall(function()
				return request("/poll?sid=" .. SID .. "&name=" .. HttpService:UrlEncode(game.Name), "GET")
			end)
			if my ~= session then
				break
			end
			if not ok then
				setStatus("Server mati / izin HTTP ditolak", false)
				if not warned then
					log("Tidak bisa konek ke " .. BASE, "err", "Jalankan 'node server.js' dan klik Allow di popup izin HTTP.")
					warned = true
				end
				task.wait(3)
			elseif res.StatusCode == 401 then
				setStatus("Token ditolak — klik Hubungkan di dashboard untuk pairing ulang", false)
				tokenStroke.Color = C.red
				tryPair()
				task.wait(3)
			elseif not res.Success then
				setStatus("Server error " .. tostring(res.StatusCode), false)
				task.wait(3)
			else
				warned = false
				tokenStroke.Color = C.green
				setStatus("Terhubung — menunggu perintah", true)
				local okj, data = pcall(function()
					return HttpService:JSONDecode(res.Body)
				end)
				if okj and type(data) == "table" and data.id then
					local okx, err = pcall(execute, data)
					if not okx then
						log("Error internal plugin", "err", tostring(err))
						reviewFrame.Visible = false
						postResults(data.id, { { tool = "internal", ok = false, output = "Error internal plugin: " .. tostring(err) } })
					end
				end
			end
		end
	end
end

function start()
	session = session + 1
	local my = session
	setStatus("Menghubungkan…", false)
	task.spawn(loop, my)
end

widget:GetPropertyChangedSignal("Enabled"):Connect(function()
	btn:SetActive(widget.Enabled)
	if widget.Enabled then
		start()
	else
		session = session + 1
		if decisionEvent then
			decisionEvent:Fire(false, "panel ditutup")
		end
	end
end)

btn.Click:Connect(function()
	widget.Enabled = not widget.Enabled
end)

plugin.Unloading:Connect(function()
	session = session + 1
end)

log("Panel ini harus terbuka supaya Studio menerima perintah.", "info")
log("v4: 32 tool · batch atomik · review diff · verify · snapshot · run_luau", "info")
if not canLoad then
	log("loadstring tidak tersedia di Studio ini", "warn", "Cek syntax otomatis dimatikan; run_luau memakai cadangan ModuleScript.")
end
