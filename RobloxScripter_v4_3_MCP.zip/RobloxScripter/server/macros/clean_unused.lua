-- Makro: clean_unused_instances
-- Menghapus (1) Folder/Model KOSONG dan (2) Part duplikat persis di Workspace.
-- DRY_RUN disuntikkan server di baris paling atas: true = hanya melaporkan, false = benar-benar menghapus.
-- Perlindungan: objek dengan Attribute, CollectionService tag, atau Attribute "RS_Keep" = true tidak disentuh.

local Workspace = game:GetService("Workspace")
local CollectionService = game:GetService("CollectionService")

local function isProtected(inst)
	if inst:GetAttribute("RS_Keep") == true then
		return true
	end
	if next(inst:GetAttributes()) ~= nil then
		return true
	end
	if #CollectionService:GetTags(inst) > 0 then
		return true
	end
	return false
end

local report = {}
local removedEmpty, removedDup = 0, 0

local function remove(inst, reason)
	table.insert(report, reason .. ": " .. inst:GetFullName())
	if not DRY_RUN then
		inst:Destroy()
	end
end

-- 1) Folder / Model kosong (ulangi: menghapus satu bisa membuat induknya kosong)
for _ = 1, 6 do
	local found = {}
	for _, inst in ipairs(Workspace:GetDescendants()) do
		if (inst:IsA("Folder") or inst:IsA("Model")) and #inst:GetChildren() == 0 and not isProtected(inst) then
			table.insert(found, inst)
		end
	end
	if #found == 0 then
		break
	end
	for _, inst in ipairs(found) do
		remove(inst, "kosong")
		removedEmpty = removedEmpty + 1
	end
	if DRY_RUN then
		break -- pada dry-run tidak ada yang benar-benar terhapus, ulangan tidak ada gunanya
	end
end

-- 2) Part duplikat persis (parent, class, nama, ukuran, posisi/rotasi, warna, material sama)
local function partKey(part)
	local comps = { part.CFrame:GetComponents() }
	for i, v in ipairs(comps) do
		comps[i] = string.format("%.3f", v)
	end
	return table.concat({
		part.ClassName,
		part.Name,
		string.format("%.3f,%.3f,%.3f", part.Size.X, part.Size.Y, part.Size.Z),
		table.concat(comps, ","),
		tostring(part.Color),
		part.Material.Name,
		tostring(part.Anchored),
		string.format("%.2f", part.Transparency),
	}, "|")
end

local seenByParent = {}
for _, inst in ipairs(Workspace:GetDescendants()) do
	if inst:IsA("BasePart") and not inst:IsA("Terrain") and inst.Parent and #inst:GetChildren() == 0 and not isProtected(inst) then
		local parentSeen = seenByParent[inst.Parent]
		if not parentSeen then
			parentSeen = {}
			seenByParent[inst.Parent] = parentSeen
		end
		local key = partKey(inst)
		if parentSeen[key] then
			remove(inst, "duplikat")
			removedDup = removedDup + 1
		else
			parentSeen[key] = true
		end
	end
end

for i = 1, math.min(#report, 40) do
	print(report[i])
end
if #report > 40 then
	print("... dan " .. (#report - 40) .. " lagi")
end

local prefix = DRY_RUN and "[PREVIEW, tidak ada yang dihapus] " or "[Selesai] "
return prefix .. removedEmpty .. " objek kosong, " .. removedDup .. " Part duplikat"
