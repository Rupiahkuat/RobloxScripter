--[[
	PlayerDataService  (dibuat oleh makro RobloxScripter: setup_datastore_boilerplate)

	Simpan data pemain dengan aman: UpdateAsync + retry, autosave, simpan saat keluar & saat server mati.
	Pemakaian dari Script server lain:
		local PlayerDataService = require(game.ServerScriptService.PlayerDataService)
		PlayerDataService.Increment(player, "Coins", 10)
		print(PlayerDataService.Get(player, "Coins"))

	Tambah field baru di DEFAULT_DATA: pemain lama otomatis mendapat nilai default-nya.
	Catatan Studio: aktifkan Game Settings > Security > "Enable Studio Access to API Services"
	(dan publish place) supaya DataStore benar-benar tersimpan saat testing.
]]

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")

local PlayerDataService = {}

local STORE_NAME = "PlayerData_v1"
local AUTOSAVE_INTERVAL = 120 -- detik
local MAX_RETRIES = 5

local DEFAULT_DATA = {
	Coins = 0,
	Level = 1,
	Joins = 0,
}

local store = DataStoreService:GetDataStore(STORE_NAME)
local cache = {} -- [UserId] = data
local canSave = {} -- [UserId] = true bila data berhasil dimuat (jangan menimpa data asli dengan default saat load gagal)
local started = false

local changedEvent = Instance.new("BindableEvent")
PlayerDataService.Changed = changedEvent.Event -- (player, key, newValue)

local function deepCopy(value)
	if type(value) ~= "table" then
		return value
	end
	local copy = {}
	for k, v in pairs(value) do
		copy[k] = deepCopy(v)
	end
	return copy
end

local function reconcile(data)
	for key, defaultValue in pairs(DEFAULT_DATA) do
		if data[key] == nil then
			data[key] = deepCopy(defaultValue)
		end
	end
	return data
end

local function withRetry(label, fn)
	local lastErr = nil
	for attempt = 1, MAX_RETRIES do
		local ok, result = pcall(fn)
		if ok then
			return true, result
		end
		lastErr = result
		warn(string.format("[PlayerData] %s gagal (percobaan %d/%d): %s", label, attempt, MAX_RETRIES, tostring(result)))
		task.wait(2 ^ attempt * 0.5)
	end
	return false, lastErr
end

function PlayerDataService.Load(player)
	local key = "Player_" .. player.UserId
	local ok, data = withRetry("load " .. player.Name, function()
		return store:GetAsync(key)
	end)
	if ok then
		local loadedData = type(data) == "table" and data or {}
		cache[player.UserId] = reconcile(loadedData)
		canSave[player.UserId] = true
		cache[player.UserId].Joins = (cache[player.UserId].Joins or 0) + 1
	else
		cache[player.UserId] = reconcile({})
		canSave[player.UserId] = false
		warn("[PlayerData] Data " .. player.Name .. " gagal dimuat; sesi ini TIDAK akan disimpan agar data lama aman.")
	end
	return cache[player.UserId]
end

function PlayerDataService.Save(player)
	local data = cache[player.UserId]
	if not data or not canSave[player.UserId] then
		return false
	end
	local key = "Player_" .. player.UserId
	local snapshot = deepCopy(data)
	local ok = withRetry("save " .. player.Name, function()
		return store:UpdateAsync(key, function()
			return snapshot
		end)
	end)
	return ok
end

function PlayerDataService.Get(player, field)
	local data = cache[player.UserId]
	if not data then
		return nil
	end
	if field == nil then
		return data
	end
	return data[field]
end

function PlayerDataService.Set(player, field, value)
	local data = cache[player.UserId]
	if not data then
		return
	end
	data[field] = value
	changedEvent:Fire(player, field, value)
end

function PlayerDataService.Increment(player, field, amount)
	local current = PlayerDataService.Get(player, field) or 0
	local newValue = current + (amount or 1)
	PlayerDataService.Set(player, field, newValue)
	return newValue
end

local function onPlayerRemoving(player)
	PlayerDataService.Save(player)
	cache[player.UserId] = nil
	canSave[player.UserId] = nil
end

function PlayerDataService.Start()
	if started then
		return
	end
	started = true

	Players.PlayerAdded:Connect(function(player)
		PlayerDataService.Load(player)
	end)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(PlayerDataService.Load, player)
	end

	Players.PlayerRemoving:Connect(onPlayerRemoving)

	task.spawn(function()
		while true do
			task.wait(AUTOSAVE_INTERVAL)
			for _, player in ipairs(Players:GetPlayers()) do
				task.spawn(PlayerDataService.Save, player)
			end
		end
	end)

	game:BindToClose(function()
		local pending = 0
		for _, player in ipairs(Players:GetPlayers()) do
			pending = pending + 1
			task.spawn(function()
				PlayerDataService.Save(player)
				pending = pending - 1
			end)
		end
		local deadline = os.clock() + 25
		while pending > 0 and os.clock() < deadline do
			task.wait(0.2)
		end
	end)
end

return PlayerDataService
