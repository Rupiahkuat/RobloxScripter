-- PlayerDataBootstrap (dibuat oleh makro RobloxScripter: setup_datastore_boilerplate)
-- Menyalakan PlayerDataService dan membuat leaderstats yang ikut berubah mengikuti data.

local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")

local PlayerDataService = require(ServerScriptService:WaitForChild("PlayerDataService"))

local LEADERSTATS = { "Coins", "Level" } -- field data yang ditampilkan di leaderboard

local function setupLeaderstats(player)
	local data
	for _ = 1, 100 do
		data = PlayerDataService.Get(player)
		if data or not player.Parent then
			break
		end
		task.wait(0.1)
	end
	if not data then
		return
	end

	local folder = Instance.new("Folder")
	folder.Name = "leaderstats"
	for _, field in ipairs(LEADERSTATS) do
		local value = Instance.new("IntValue")
		value.Name = field
		value.Value = tonumber(data[field]) or 0
		value.Parent = folder
	end
	folder.Parent = player
end

PlayerDataService.Changed:Connect(function(player, field, newValue)
	local folder = player:FindFirstChild("leaderstats")
	local value = folder and folder:FindFirstChild(field)
	if value and value:IsA("IntValue") then
		value.Value = tonumber(newValue) or 0
	end
end)

Players.PlayerAdded:Connect(setupLeaderstats)
for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(setupLeaderstats, player)
end

PlayerDataService.Start()
