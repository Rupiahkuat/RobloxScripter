-- Makro: optimize_ui_scales (langkah 1)
-- Memasang UIScale bernama "AutoUIScale" di setiap ScreenGui pada StarterGui (kalau belum ada).
-- DRY_RUN disuntikkan server di baris paling atas.

local StarterGui = game:GetService("StarterGui")

local added, skipped = 0, 0
for _, gui in ipairs(StarterGui:GetChildren()) do
	if gui:IsA("ScreenGui") then
		if gui:FindFirstChildOfClass("UIScale") then
			skipped = skipped + 1
		else
			print("UIScale -> " .. gui:GetFullName())
			if not DRY_RUN then
				local scale = Instance.new("UIScale")
				scale.Name = "AutoUIScale"
				scale.Scale = 1
				scale.Parent = gui
			end
			added = added + 1
		end
	end
end

local prefix = DRY_RUN and "[PREVIEW, tidak ada yang diubah] " or "[Selesai] "
return prefix .. added .. " ScreenGui diberi UIScale, " .. skipped .. " sudah punya UIScale"
