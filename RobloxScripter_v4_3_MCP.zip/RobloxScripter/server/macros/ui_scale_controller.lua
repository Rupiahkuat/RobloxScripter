-- AutoUIScaler (dibuat oleh makro RobloxScripter: optimize_ui_scales)
-- Menyesuaikan UIScale "AutoUIScale" di semua ScreenGui agar UI yang didesain untuk 1920x1080
-- tetap pas di layar kecil (HP/tablet) maupun besar. ScreenGui dengan Attribute NoAutoScale = true dilewati.

local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")

local BASE_RESOLUTION = Vector2.new(1920, 1080)
local MIN_SCALE = 0.45
local MAX_SCALE = 1.6

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local camera = Workspace.CurrentCamera

local function computeScale()
	local viewport = camera.ViewportSize
	local scale = math.min(viewport.X / BASE_RESOLUTION.X, viewport.Y / BASE_RESOLUTION.Y)
	return math.clamp(scale, MIN_SCALE, MAX_SCALE)
end

local function apply(gui)
	if not gui:IsA("ScreenGui") or gui:GetAttribute("NoAutoScale") == true then
		return
	end
	local scale = gui:FindFirstChild("AutoUIScale")
	if scale and scale:IsA("UIScale") then
		scale.Scale = computeScale()
	end
end

local function applyAll()
	for _, gui in ipairs(playerGui:GetChildren()) do
		apply(gui)
	end
end

playerGui.ChildAdded:Connect(function(child)
	task.defer(apply, child)
end)
camera:GetPropertyChangedSignal("ViewportSize"):Connect(applyAll)
applyAll()
