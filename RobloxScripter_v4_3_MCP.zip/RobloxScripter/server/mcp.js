#!/usr/bin/env node
// RobloxScripter - MCP server (stdio), tanpa dependency. Menggantikan ekstensi browser.
//
//   AI client (Claude Desktop / Claude Code / Cursor / ...) --MCP stdio--> mcp.js --HTTP--> server.js <--poll-- Plugin Studio
//
// mcp.js otomatis menyalakan server.js (tanpa jendela) kalau belum jalan, dan memakai token dari server/.rs_token.
// Semua tool sama seperti sebelumnya (32 tool). Kode Lua dikirim langsung lewat argumen (source / code / find / replace).

"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const PORT = Number(process.env.PORT) || 3030;
const HOST = "127.0.0.1";
const TOKEN_FILE = path.join(__dirname, ".rs_token");
const VERSION = "4.3";
const WAIT_TOTAL_MS = 5 * 60 * 1000; // batas tunggu hasil (review popup di Studio bisa makan waktu)
const OUT_LIMIT = { project_snapshot: 15000, get_script_source: 12000, verify: 9000, script_outline: 8000 };
const DEFAULT_LIMIT = 6000;

const log = (...a) => process.stderr.write("[rs-mcp] " + a.join(" ") + "\n");

// ---------------------------------------------------------------- HTTP ke server.js
function req(method, p, body, token, timeout) {
	return new Promise((resolve, reject) => {
		const data = body ? JSON.stringify(body) : null;
		const headers = { Host: `${HOST}:${PORT}` };
		if (token) headers["X-RS-Token"] = token;
		if (data) { headers["Content-Type"] = "application/json"; headers["Content-Length"] = Buffer.byteLength(data); }
		const r = http.request({ host: HOST, port: PORT, path: p, method, headers, timeout: timeout || 20000 }, (res) => {
			let s = "";
			res.on("data", (c) => (s += c));
			res.on("end", () => {
				let j = null;
				try { j = JSON.parse(s); } catch (_) {}
				resolve({ status: res.statusCode, json: j, text: s });
			});
		});
		r.on("timeout", () => r.destroy(new Error("timeout")));
		r.on("error", reject);
		if (data) r.write(data);
		r.end();
	});
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const readToken = () => { try { return fs.readFileSync(TOKEN_FILE, "utf8").trim(); } catch (_) { return ""; } };

let starting = null;
async function ensureServer() {
	const alive = async () => { try { return (await req("GET", "/health", null, null, 1500)).status === 200; } catch (_) { return false; } };
	if (await alive()) return;
	if (!starting) {
		starting = (async () => {
			log("server belum jalan, menyalakan server.js ...");
			const child = spawn(process.execPath, [path.join(__dirname, "server.js")], {
				cwd: __dirname, detached: true, stdio: "ignore", windowsHide: true,
			});
			child.unref();
			for (let i = 0; i < 40; i++) { await sleep(250); if (await alive()) return; }
			throw new Error("server.js tidak mau menyala di port " + PORT + " (port dipakai program lain?)");
		})().finally(() => { starting = null; });
	}
	await starting;
}

async function authed(method, p, body, timeout) {
	await ensureServer();
	for (let i = 0; i < 20 && !readToken(); i++) await sleep(200);
	let r = await req(method, p, body, readToken(), timeout);
	if (r.status === 401) { await sleep(300); r = await req(method, p, body, readToken(), timeout); } // token baru dibuat
	return r;
}

// ---------------------------------------------------------------- definisi tool
const S = (type, extra) => Object.assign({ type }, extra || {});
const str = (d) => S("string", { description: d });
const num = (d) => S("number", { description: d });
const bool = (d) => S("boolean", { description: d });
const obj = (d) => S("object", { description: d });
const arr = (d, items) => S("array", { description: d, items: items || {} });
const strs = (d) => arr(d, S("string"));
const vec = (d) => arr(d, S("number"));
const T = (name, description, props, required, readOnly) => ({
	name, description,
	inputSchema: { type: "object", properties: props || {}, required: required || [], additionalProperties: true },
	annotations: { readOnlyHint: !!readOnly, openWorldHint: false },
});

const PATH_D = 'Instance path in GetFullName format, e.g. "Workspace.Map.Door", "ServerScriptService". Duplicate names: add #n ("Workspace.Part#2" = 2nd child named Part). "game" = root.';
const PROPS_D = "Property map {Name: value}. Vector3=[x,y,z], Vector2=[x,y], Color3=[r,g,b] 0-255 or \"#RRGGBB\", CFrame=[x,y,z] or [x,y,z,rotX,rotY,rotZ] degrees, UDim2=[xScale,xOffset,yScale,yOffset], UDim=[scale,offset], NumberRange=[min,max], Enum=name string, BrickColor=name, Instance=path string.";

const TOOLS = [
	// ---- BACA
	T("project_snapshot", "Map of the whole game: structure, scripts + their functions, remotes. RUN THIS FIRST for an existing game.", { max_chars: num("Max output characters") }, [], true),
	T("list_children", "Contents of an object.", { path: str(PATH_D), depth: num("1-4") }, ["path"], true),
	T("find_instances", "Find instances by class and/or name.", { root: str("Search root path"), class_name: str("ClassName"), name_contains: str("Substring of Name"), limit: num("Max results") }, [], true),
	T("get_properties", "Read properties of an instance.", { path: str(PATH_D), properties: strs("Property names to read") }, ["path", "properties"], true),
	T("get_selection", "Instances currently selected in Studio.", {}, [], true),
	T("get_script_source", "Read a script's source, optionally by line range.", { path: str(PATH_D), start_line: num("1-based"), end_line: num("1-based") }, ["path"], true),
	T("script_outline", "Outline of a script: functions + line numbers, requires, TODOs. Use for big scripts, then read by range.", { path: str(PATH_D) }, ["path"], true),
	T("search_scripts", "Search text across all scripts.", { query: str("Text to find"), root: str("Search root path") }, ["query"], true),
	T("search_toolbox", "Search free Toolbox assets.", { query: str("Search query"), page: num("Page number") }, ["query"], true),
	T("get_output", "Read Studio Output errors/warnings.", { level: S("string", { enum: ["error", "warning", "all"] }), limit: num("Max lines") }, [], true),
	T("verify", "Automatic audit: syntax of all scripts, remotes without handler, loops without wait, deprecated wait()/spawn(), unanchored Parts, backdoor-like patterns.", { path: str(PATH_D) }, [], true),
	// ---- UBAH
	T("create_instance", "Create an instance.", { class_name: str("ClassName"), parent_path: str(PATH_D), name: str("Name"), properties: obj(PROPS_D) }, ["class_name", "parent_path"]),
	T("set_properties", "Set properties on one instance.", { path: str(PATH_D), properties: obj(PROPS_D) }, ["path", "properties"]),
	T("bulk_set_properties", "Set properties on many instances at once. Needs at least one filter.", { root: str("Root path"), class_name: str("ClassName filter"), name_contains: str("Name filter"), tag: str("CollectionService tag filter"), properties: obj(PROPS_D), limit: num("Max instances") }, ["properties"]),
	T("create_tree", "Create many instances/Models at once (max 300 nodes).", { parent_path: str(PATH_D), tree: obj("Node {class, name?, props?, children?:[...]}") }, ["parent_path", "tree"]),
	T("move_instance", "Reparent an instance.", { path: str(PATH_D), new_parent_path: str(PATH_D) }, ["path", "new_parent_path"]),
	T("delete_instance", "Delete an instance (user approves in Studio).", { path: str(PATH_D) }, ["path"]),
	T("clone_instance", "Clone an instance 1-100 times.", { path: str(PATH_D), parent_path: str(PATH_D), name: str("Name"), count: num("1-100"), offset: vec("[x,y,z] per clone"), properties: obj(PROPS_D) }, ["path"]),
	T("group_instances", "Group instances into a Model or Folder.", { paths: strs("Instance paths"), name: str("Group name"), class: S("string", { enum: ["Model", "Folder"] }), parent_path: str(PATH_D) }, ["paths"]),
	T("arrange_instances", "Arrange instances in a grid/line/circle or align them.", { paths: strs("Instance paths (or use parent_path)"), parent_path: str(PATH_D), mode: S("string", { enum: ["grid", "line", "circle", "align"] }), origin: vec("[x,y,z]"), spacing: S(["number", "array"], { description: "n or [sx,sz]" }), columns: num("Grid columns"), axis: S("string", { enum: ["X", "Y", "Z"] }), radius: num("Circle radius"), face_center: bool("Face the center") }, ["mode"]),
	T("set_attributes", "Set attributes on an instance.", { path: str(PATH_D), attributes: obj("{name: value}") }, ["path", "attributes"]),
	T("tag", "Add/remove CollectionService tags.", { path: str(PATH_D), add: strs("Tags to add"), remove: strs("Tags to remove") }, ["path"]),
	// ---- SCRIPT
	T("create_script", "Create a script. Syntax errors are rejected by the plugin (fix and resend). User may review in Studio.", { script_type: S("string", { enum: ["Script", "LocalScript", "ModuleScript"] }), parent_path: str(PATH_D), name: str("Script name"), source: str("Full Luau source"), run_context: str("Optional RunContext") }, ["script_type", "parent_path", "name", "source"]),
	T("edit_script", "Edit a script: either full `source`, or `find`+`replace` (find must be exact and unique). Prefer find/replace for small edits.", { path: str(PATH_D), source: str("Full new source"), find: str("Exact unique text to find"), replace: str("Replacement text") }, ["path"]),
	T("replace_in_scripts", "Find/replace across ALL scripts. Use dry_run first to see the impact.", { find: str("Text to find"), replace: str("Replacement"), root: str("Root path"), dry_run: bool("Only report, change nothing") }, ["find", "replace"]),
	T("run_luau", "Run one-off Luau in Studio (edit mode); returns print/warn output + return value. Always needs user approval in Studio.", { code: str("Luau code"), timeout: num("1-60 seconds") }, ["code"]),
	// ---- UI
	T("create_gui", "Build a UI tree with themes and shorthands. tree node = {class?(default Frame), name, props?, text?, children?, corner:8, stroke:{thickness,color,transparency}, gradient:{colors,rotation}, padding:8|[l,t,r,b], list:{direction:'V'|'H',padding,halign?,valign?}, grid:{cell:[w,h],padding}, aspect:1.5}. Colors: theme tokens \"$bg\" \"$surface\" \"$surface2\" \"$primary\" \"$accent\" \"$text\" \"$subtext\" \"$danger\" \"$success\", [r,g,b] or \"#RRGGBB\". Use Scale for responsive UI.", { parent_path: str("Default StarterGui"), theme: S(["string", "object"], { description: '"dark" | "light" | "neon" | {token:[r,g,b]}' }), tree: obj("UI node tree") }, ["tree"]),
	// ---- DUNIA
	T("terrain", "Generate terrain.", { shape: S("string", { enum: ["block", "ball", "cylinder", "hills", "clear"] }), position: vec("[x,y,z]"), size: S(["array", "number"], { description: "[x,y,z] or for hills [x,z]" }), radius: num("Radius"), height: num("Hills height"), scale: num("Noise scale"), seed: num("Seed"), material: str("Enum.Material name") }, ["shape"]),
	T("set_lighting", "Set Lighting properties and effects (Atmosphere, Sky, BloomEffect, ColorCorrectionEffect, SunRaysEffect, DepthOfFieldEffect).", { properties: obj("Lighting properties"), effects: obj('{"Atmosphere":{..},"Sky":{..},"BloomEffect":{..},...}') }),
	T("insert_asset", "Insert a Toolbox asset (user may review).", { asset_id: num("Asset id"), parent_path: str(PATH_D), position: vec("[x,y,z]"), name: str("Name"), allow_scripts: bool("Keep scripts inside the asset") }, ["asset_id"]),
	T("scatter_instances", "Scatter copies of a template Model/Part (keep it in ServerStorage) over an area.", { template_path: str(PATH_D), parent_path: str(PATH_D), center: vec("[x,y,z]"), size: vec("[x,z]"), count: num("1-200"), min_distance: num("Min spacing"), random_rotation: bool("Random Y rotation"), scale_range: vec("[min,max]"), align_to_ground: bool("Raycast to ground (default true)"), seed: num("Seed"), name: str("Name") }, ["template_path", "center", "size", "count"]),
	// ---- UJI
	T("playtest", "Run the game briefly and return all errors/warnings during it (experimental).", { mode: S("string", { enum: ["play", "run"] }), duration: num("3-120 seconds") }),
];
const TOOL_NAMES = new Set(TOOLS.map((t) => t.name));

const INSTRUCTIONS = [
	"RobloxScripter: control Roblox Studio (inspect, build, script, UI, terrain, playtest) through the Studio plugin.",
	"Workflow: (1) project_snapshot if the game already exists, (2) build the feature, (3) run verify, (4) for gameplay logic run playtest and read its errors, (5) fix until clean, then summarize briefly.",
	"Small edits: edit_script with find/replace, not whole rewrites. Big scripts: script_outline first, then get_script_source by line range.",
	"Use modern Luau: task.wait (not wait), task.spawn, +=. Server logic in Script (ServerScriptService), input/UI in LocalScript (StarterPlayerScripts/StarterGui), shared code in ModuleScript (ReplicatedStorage). Validate all client input on the server.",
	"New Parts: Anchored=true unless physics is needed, and give clear Names.",
	"Script changes, deletes, insert_asset, replace_in_scripts and run_luau may be reviewed by the user in Studio and rejected. If a result says rejected, do not repeat it unchanged: ask the user or change approach.",
	"Scripts with syntax errors are rejected automatically by the plugin with the error message: fix and resend.",
	"If a tool says the Studio plugin is not connected: ask the user to open Roblox Studio, open Plugins > RobloxScripter, and pair it from the dashboard at http://127.0.0.1:" + PORT + "/.",
].join("\n");

// ---------------------------------------------------------------- eksekusi tool
function fmt(tool, r) {
	let out = r && r.output != null ? (typeof r.output === "string" ? r.output : JSON.stringify(r.output)) : "";
	const lim = OUT_LIMIT[tool] || DEFAULT_LIMIT;
	if (out.length > lim) out = out.slice(0, lim) + `\n...[dipotong, ${out.length - lim} karakter lagi; pakai argumen yang lebih sempit]`;
	return out || (r && r.ok ? "OK" : "(tanpa output)");
}

async function runTool(name, args) {
	if (!TOOL_NAMES.has(name)) return { isError: true, content: [{ type: "text", text: "Tool tidak dikenal: " + name }] };
	const action = Object.assign({}, args || {}, { tool: name });
	let sub;
	try {
		sub = await authed("POST", "/commands", { actions: [action] }, 15000);
	} catch (e) {
		return { isError: true, content: [{ type: "text", text: "Tidak bisa menghubungi server RobloxScripter: " + e.message }] };
	}
	if (sub.status !== 200 || !sub.json) {
		return { isError: true, content: [{ type: "text", text: "Server menolak perintah: " + ((sub.json && sub.json.error) || sub.text || sub.status) }] };
	}
	if (!sub.json.pluginConnected) {
		return { isError: true, content: [{ type: "text", text: "Plugin Roblox Studio belum terhubung. Buka Roblox Studio > Plugins > RobloxScripter, lalu pairing lewat dashboard http://127.0.0.1:" + PORT + "/ (tombol Connect). Setelah itu coba lagi." }] };
	}
	const id = sub.json.id;
	const t0 = Date.now();
	while (Date.now() - t0 < WAIT_TOTAL_MS) {
		let r;
		try { r = await authed("GET", "/results?id=" + id + "&wait=1", null, 20000); } catch (e) { await sleep(500); continue; }
		if (r.json && r.json.done) {
			const list = Array.isArray(r.json.results) ? r.json.results : [];
			const one = list[0];
			if (!one) return { isError: true, content: [{ type: "text", text: "Hasil kosong dari plugin." }] };
			return { isError: !one.ok, content: [{ type: "text", text: fmt(name, one) }] };
		}
	}
	return { isError: true, content: [{ type: "text", text: "Timeout menunggu hasil dari Studio (mungkin popup review belum dijawab di Studio). Perintah #" + id + " mungkin masih berjalan: cek dengan get_output atau coba lagi." }] };
}

// ---------------------------------------------------------------- MCP (JSON-RPC lewat stdio, satu JSON per baris)
const send = (m) => process.stdout.write(JSON.stringify(m) + "\n");
const ok = (id, result) => send({ jsonrpc: "2.0", id, result });
const fail = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });

async function handle(m) {
	const { id, method, params } = m;
	const isReq = id !== undefined && id !== null;
	switch (method) {
		case "initialize":
			return ok(id, {
				protocolVersion: (params && params.protocolVersion) || "2025-03-26",
				capabilities: { tools: { listChanged: false } },
				serverInfo: { name: "roblox-scripter", version: VERSION },
				instructions: INSTRUCTIONS,
			});
		case "ping": return isReq && ok(id, {});
		case "tools/list": return ok(id, { tools: TOOLS });
		case "tools/call": {
			const p = params || {};
			try { return ok(id, await runTool(p.name, p.arguments)); }
			catch (e) { return ok(id, { isError: true, content: [{ type: "text", text: "Error internal: " + e.message }] }); }
		}
		case "resources/list": return ok(id, { resources: [] });
		case "prompts/list": return ok(id, { prompts: [] });
		default:
			if (isReq) return fail(id, -32601, "Method not found: " + method);
	}
}

let buf = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
	buf += chunk;
	let i;
	while ((i = buf.indexOf("\n")) >= 0) {
		const line = buf.slice(0, i).trim();
		buf = buf.slice(i + 1);
		if (!line) continue;
		let m;
		try { m = JSON.parse(line); } catch (_) { continue; }
		Promise.resolve(handle(m)).catch((e) => log("error:", e.message));
	}
});
process.stdin.on("end", () => process.exit(0));
// Warm-up: nyalakan server segera supaya dashboard siap saat tool pertama dipanggil.
ensureServer().catch((e) => log(e.message));
