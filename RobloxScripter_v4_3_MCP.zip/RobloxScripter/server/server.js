// RobloxScripter - server jembatan v4.2 (tanpa dependency, cukup Node.js 16+)
// Jalankan:  node server.js          (token baru:  node server.js --new-token)
//            node server.js --sync-dir D:\MyGame\src   (folder sinkron lain)   |   --no-sync (matikan sinkron file)
//
// Perintah : Ekstensi --(POST /commands)--> server <--(GET /poll)-- Plugin Studio
// Hasil    : Plugin --(POST /results)--> server <--(GET /results?wait=1)-- Ekstensi
// Auto-debug: Plugin --(POST /events)--> server <--(GET /events)-- Ekstensi
//
// v4.2 (baru):
//  * LOCAL FILE SYNCING (Rojo mini): semua script di Studio dicerminkan sebagai file .lua asli di folder src/.
//    AI menulis -> file di PC ikut berubah. Edit di VS Code / Cursor -> script di Studio ikut berubah.
//  * SCRIPT HISTORY + UNDO: tiap batch AI dibandingkan (sebelum/sesudah) -> riwayat per script, bisa di-Undo dari dashboard.
//  * MAKRO "sekali klik": tools.json > commands, dijalankan dari dashboard (POST /api/macro/run).
//  * ERROR HIGHLIGHTER: error Output Studio + petunjuk solusi instan + konteks kode untuk dashboard.
//
// KEAMANAN (sejak v3): semua endpoint (kecuali /health) butuh header X-RS-Token. Token dibuat otomatis
// saat server pertama jalan (file .rs_token) dan ditampilkan di console. Host header & Origin
// juga diperiksa (anti DNS-rebinding / website jahil).
// v4.2: tool internal (sync_script, dump_scripts) DITOLAK di /commands: hanya server ini yang boleh memakainya,
// jadi AI tidak bisa menulis script tanpa review lewat jalur sinkronisasi.

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const fsmap = require("./lib/fsmap");
const { diffLines, compact } = require("./lib/diff");
const { hintFor, locate } = require("./lib/hints");

const VERSION = "4.2";
const PORT = Number(process.env.PORT) || 3030;
const HOST = "127.0.0.1";
const POLL_HOLD_MS = 10000;
const RESULT_HOLD_MS = 15000;
const TOKEN_FILE = path.join(__dirname, ".rs_token");
const ROOT_DIR = path.join(__dirname, "..");
const DATA_DIR = path.join(__dirname, ".rs_data");
const CONFIG_FILE = path.join(__dirname, "rs_config.json");

function argValue(name) {
	const i = process.argv.findIndex((a) => a === name || a.startsWith(name + "="));
	if (i < 0) return null;
	const a = process.argv[i];
	if (a.includes("=")) return a.slice(name.length + 1);
	return process.argv[i + 1] && !process.argv[i + 1].startsWith("--") ? process.argv[i + 1] : null;
}

function loadToken() {
	if (process.argv.includes("--new-token")) {
		try { fs.unlinkSync(TOKEN_FILE); } catch (e) {}
	}
	try {
		const t = fs.readFileSync(TOKEN_FILE, "utf8").trim();
		if (/^[0-9a-f]{24,}$/.test(t)) return t;
	} catch (e) {}
	const t = crypto.randomBytes(18).toString("hex");
	fs.writeFileSync(TOKEN_FILE, t, { mode: 0o600 });
	return t;
}
const TOKEN = loadToken();
const TOKEN_BUF = Buffer.from(TOKEN);

// ---------------------------------------------------------------- konfigurasi (rs_config.json)
const config = { syncEnabled: true, syncDir: "src" };
try {
	const c = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
	if (c.syncEnabled === false) config.syncEnabled = false;
	if (typeof c.syncDir === "string" && c.syncDir.trim()) config.syncDir = c.syncDir.trim();
} catch (e) {}
if (process.argv.includes("--no-sync")) config.syncEnabled = false;
const SYNC_DIR = path.resolve(ROOT_DIR, argValue("--sync-dir") || process.env.RS_SYNC_DIR || config.syncDir);
function saveConfig() {
	try { fs.writeFileSync(CONFIG_FILE, JSON.stringify({ syncEnabled: config.syncEnabled, syncDir: config.syncDir }, null, 2)); } catch (e) {}
}

const DASH_FILE = path.join(__dirname, "dashboard.html");
const TOOLS_FILE = path.join(__dirname, "tools.json");
const LOGO_FILE = path.join(__dirname, "..", "extension", "icons", "icon128.png");
const STARTED = Date.now();
const history = []; // riwayat batch (maks 100): {id,time,tools,ok,total,ms,label,detail}
const cmdMeta = new Map(); // id -> {t, tools, label}
let pairUntil = 0; // jendela pairing otomatis (dibuka dari dashboard)

function tokenOk(given) {
	if (typeof given !== "string") return false;
	const b = Buffer.from(given);
	return b.length === TOKEN_BUF.length && crypto.timingSafeEqual(b, TOKEN_BUF);
}

let nextId = 1;
const plugins = new Map(); // sid -> { sid, name, seen, queue: [], waiter: null }
let activeSid = null;
const pendingQueue = []; // perintah yang masuk sebelum ada plugin
const results = new Map(); // id -> hasil
const resultWaiters = new Map(); // id -> [{res, timer}]

const events = []; // log Output Studio (error/warning), maks 500
let eventSeq = 0;

function send(res, code, obj) {
	if (res.writableEnded) return;
	res.writeHead(code, { "Content-Type": "application/json" });
	res.end(JSON.stringify(obj));
}

function readJson(req, limit) {
	limit = limit || 5 * 1024 * 1024;
	return new Promise((resolve, reject) => {
		let size = 0;
		const chunks = [];
		req.on("data", (c) => {
			size += c.length;
			if (size > limit) {
				reject(new Error("body terlalu besar"));
				req.destroy();
				return;
			}
			chunks.push(c);
		});
		req.on("end", () => {
			try {
				resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"));
			} catch (e) {
				reject(e);
			}
		});
		req.on("error", reject);
	});
}

function touchPlugin(sid, name) {
	sid = sid || "default";
	let p = plugins.get(sid);
	if (!p) {
		p = { sid, name: name || "Studio", seen: 0, queue: [], waiter: null };
		plugins.set(sid, p);
		console.log(`[plugin] terhubung: ${p.name} (${sid.slice(0, 8)})`);
		if (!activeSid || !plugins.has(activeSid)) activeSid = sid;
		if (pendingQueue.length && activeSid === sid) p.queue.push(...pendingQueue.splice(0));
		if (activeSid === sid) scheduleBaseline("plugin baru");
	}
	if (name) p.name = name;
	p.seen = Date.now();
	return p;
}

function pruneAndActive() {
	const now = Date.now();
	for (const [sid, p] of plugins) {
		if (!p.waiter && now - p.seen > 90000) plugins.delete(sid);
	}
	const act = plugins.get(activeSid);
	if (!act || (!act.waiter && now - act.seen > 30000)) {
		let best = null;
		for (const p of plugins.values()) if (!best || p.seen > best.seen) best = p;
		activeSid = best ? best.sid : null;
	}
}

function flush(p) {
	if (p.waiter && p.queue.length) {
		clearTimeout(p.waiter.timer);
		const w = p.waiter;
		p.waiter = null;
		send(w.res, 200, p.queue.shift());
	}
}

function pluginConnected() {
	const now = Date.now();
	for (const p of plugins.values()) if (p.waiter || now - p.seen < 30000) return true;
	return false;
}

function hasActivePlugin() {
	pruneAndActive();
	return !!plugins.get(activeSid) && pluginConnected();
}

// Masukkan batch ke antrean Studio aktif (atau antrean tunggu bila belum ada plugin)
function enqueue(batch) {
	pruneAndActive();
	const p = plugins.get(activeSid);
	if (p) {
		p.queue.push(batch);
		flush(p);
	} else {
		pendingQueue.push(batch);
	}
}

function filterLevel(list, level) {
	return level === "all" ? list : list.filter((e) => e.level === level);
}

// ================================================================ tools.json, makro
function loadTools() {
	return JSON.parse(fs.readFileSync(TOOLS_FILE, "utf8"));
}
const FALLBACK_READ = ["project_snapshot", "list_children", "find_instances", "get_properties", "get_selection", "get_script_source", "script_outline", "search_scripts", "search_toolbox", "get_output", "verify", "dump_scripts"];
function readToolSet() {
	const s = new Set(FALLBACK_READ);
	try { for (const t of loadTools().tools) if (t.r) s.add(t.n); } catch (e) {}
	return s;
}
// Tool yang tidak pernah menyentuh script: tidak perlu snapshot sebelum/sesudah
const NO_SCRIPT_EFFECT = new Set(["terrain", "set_lighting", "scatter_instances", "arrange_instances", "tag", "set_attributes", "verify", "playtest"]);
// Tool internal: hanya server yang boleh memakainya
const INTERNAL_TOOLS = new Set(["sync_script", "dump_scripts"]);

function isTrackable(actions) {
	const rd = readToolSet();
	return actions.some((a) => !rd.has(a.tool) && !NO_SCRIPT_EFFECT.has(a.tool) && !(a.tool === "replace_in_scripts" && a.dry_run === true));
}

const MACRO_DIR = path.join(__dirname, "macros");
function resolveMacroValue(v) {
	if (typeof v === "string" && v.startsWith("@file:")) {
		const abs = path.resolve(__dirname, v.slice(6));
		if (!abs.startsWith(MACRO_DIR + path.sep)) throw new Error("file makro harus di folder server/macros: " + v);
		return fs.readFileSync(abs, "utf8");
	}
	return v;
}

// ================================================================ eksekusi internal (server -> plugin)
const internalWait = new Map(); // id -> callback(list)
const internalIds = new Set();
const jobWaiters = new Map(); // id -> callback(list) untuk batch "tracked"

function runInternal(actions, timeoutMs) {
	return new Promise((resolve) => {
		if (!hasActivePlugin()) return resolve(null);
		const id = nextId++;
		internalIds.add(id);
		if (internalIds.size > 500) internalIds.delete(internalIds.values().next().value);
		const timer = setTimeout(() => {
			internalWait.delete(id);
			resolve(null);
		}, timeoutMs || 20000);
		internalWait.set(id, (list) => {
			clearTimeout(timer);
			resolve(list);
		});
		enqueue({ id, actions, quiet: true });
	});
}

// Jalankan batch "nyata" (tampil di riwayat & log Studio) dan tunggu hasilnya
function runUserBatch(actions, meta, timeoutMs) {
	return new Promise((resolve) => {
		const id = nextId++;
		cmdMeta.set(id, { t: Date.now(), tools: actions.map((a) => a.tool), label: (meta && meta.label) || null });
		const timer = setTimeout(() => {
			jobWaiters.delete(id);
			resolve({ id, results: null });
		}, timeoutMs || 5 * 60 * 1000);
		jobWaiters.set(id, (list) => {
			clearTimeout(timer);
			resolve({ id, results: list });
		});
		enqueue({ id, actions });
	});
}

// Antrean serial: satu "pekerjaan terlacak" pada satu waktu supaya foto sebelum/sesudah tidak bercampur
let chain = Promise.resolve();
let busyJobs = 0;
function serial(fn) {
	busyJobs++;
	const p = chain.then(fn, fn).finally(() => { busyJobs--; });
	chain = p.catch(() => {});
	return p;
}

// ================================================================ snapshot script, riwayat, undo
const snap = new Map(); // key -> {segs, cls, source}
let parentsSet = new Set(); // key semua script yang punya anak script
let baselineDone = false;
let snapSid = null;
let snapAt = 0;
let lastJob = null; // {t, label, ok, msg}

const versions = []; // {vid,t,key,segs,cls,origin,batch,label,before,after,add,del,undoOf}
let versionSeq = 0;
const VERSION_LIMIT = 300;
const VERSION_CHARS = 30 * 1000 * 1000;

function setLastJob(label, ok, msg) {
	lastJob = { t: Date.now(), label, ok, msg: String(msg || "").slice(0, 2000) };
}

function loadHistory() {
	try {
		const j = JSON.parse(fs.readFileSync(path.join(DATA_DIR, "history.json"), "utf8"));
		if (Array.isArray(j.versions)) {
			for (const v of j.versions) if (v && Array.isArray(v.segs)) versions.push(v);
			versionSeq = Math.max(Number(j.seq) || 0, ...versions.map((v) => v.vid), 0);
		}
	} catch (e) {}
}
let saveTimer = null;
function saveHistorySoon() {
	if (saveTimer) return;
	saveTimer = setTimeout(() => {
		saveTimer = null;
		try {
			fs.mkdirSync(DATA_DIR, { recursive: true });
			const tmp = path.join(DATA_DIR, "history.json.tmp");
			fs.writeFileSync(tmp, JSON.stringify({ seq: versionSeq, versions }));
			fs.renameSync(tmp, path.join(DATA_DIR, "history.json"));
		} catch (e) {
			console.log("[history] gagal menyimpan: " + e.message);
		}
	}, 1500);
}
loadHistory();

function recordVersion(c, meta) {
	const before = c.before == null ? null : c.before;
	const after = c.after == null ? null : c.after;
	const d = diffLines(before || "", after || "");
	const v = {
		vid: ++versionSeq,
		t: Date.now(),
		key: fsmap.keyOf(c.segs),
		segs: c.segs,
		cls: c.cls,
		origin: meta.origin || "ai",
		batch: meta.batch || null,
		label: meta.label || null,
		undoOf: meta.undoOf || null,
		before,
		after,
		add: d.add,
		del: d.del,
	};
	versions.push(v);
	let chars = 0;
	for (const x of versions) chars += (x.before || "").length + (x.after || "").length;
	while (versions.length > VERSION_LIMIT || (chars > VERSION_CHARS && versions.length > 20)) {
		const o = versions.shift();
		chars -= (o.before || "").length + (o.after || "").length;
	}
	saveHistorySoon();
	console.log(`[history] v${v.vid} ${fsmap.dotted(c.segs)} (${v.origin}) +${v.add} -${v.del}`);
	return v;
}

function rebuildParents() {
	parentsSet = new Set();
	for (const v of snap.values()) {
		for (let i = 1; i < v.segs.length; i++) parentsSet.add(fsmap.keyOf(v.segs.slice(0, i)));
	}
}

// Ambil semua script dari Studio (dipecah per chunk). -> Map key -> {segs, cls, source} atau null bila gagal
async function dumpAll() {
	const out = new Map();
	let after = 0;
	for (let guard = 0; guard < 400; guard++) {
		const r = await runInternal([{ tool: "dump_scripts", after, max_bytes: 300000 }], 40000);
		if (!r || !r[0] || !r[0].ok) return null;
		let j;
		try { j = JSON.parse(r[0].output); } catch (e) { return null; }
		for (const s of j.scripts || []) {
			if (Array.isArray(s.segs) && typeof s.source === "string") out.set(fsmap.keyOf(s.segs), { segs: s.segs, cls: s.class, source: s.source });
		}
		if (j.next == null) return out;
		after = j.next;
	}
	return null;
}

// Source satu script sekarang: string | null (tidak ada) | undefined (tidak diketahui)
async function fetchCurrent(segs) {
	const r = await runInternal([{ tool: "get_script_source", path: segs }], 15000);
	if (!r || !r[0]) return undefined;
	return r[0].ok ? String(r[0].output) : null;
}

// Perubahan yang dilakukan manual di Studio (di luar AI) ikut dicatat & ditulis ke file
function absorbStudioChanges(fresh) {
	if (!baselineDone || !fresh) return 0;
	return reconcile(new Map(snap), fresh, { origin: "studio" });
}

// Bandingkan foto sebelum & sesudah -> catat versi, perbarui snapshot, tulis file
function reconcile(pre, post, meta) {
	const changes = [];
	for (const [k, v] of post) {
		const o = pre.get(k);
		if (!o) changes.push({ key: k, segs: v.segs, cls: v.cls, before: null, after: v.source });
		else if (o.source !== v.source || o.cls !== v.cls) changes.push({ key: k, segs: v.segs, cls: v.cls, before: o.source, after: v.source });
	}
	for (const [k, o] of pre) if (!post.has(k)) changes.push({ key: k, segs: o.segs, cls: o.cls, before: o.source, after: null });
	for (const c of changes) recordVersion(c, meta);
	snap.clear();
	for (const [k, v] of post) snap.set(k, v);
	snapAt = Date.now();
	rebuildParents();
	if (config.syncEnabled) syncDisk(changes);
	return changes.length;
}

// Perubahan yang hasilnya sudah pasti (sync dari file / undo)
function applyKnown(e, before, meta) {
	const key = fsmap.keyOf(e.segs);
	const prevEntry = snap.get(key);
	const prev = before !== undefined ? before : prevEntry ? prevEntry.source : null;
	const after = e.source == null ? null : e.source;
	if (prev === after) return;
	if (prev !== null && after !== null && fsmap.norm(prev) === fsmap.norm(after)) {
		snap.set(key, { segs: e.segs, cls: e.cls, source: after });
		return;
	}
	const c = { key, segs: e.segs, cls: e.cls, before: prev, after };
	recordVersion(c, meta);
	if (meta.rel && after !== null) manifest.set(key, meta.rel);
	if (after === null) snap.delete(key);
	else snap.set(key, { segs: e.segs, cls: e.cls, source: after });
	rebuildParents();
	if (config.syncEnabled) syncDisk([c]);
}

// Jalankan aksi yang hasilnya diketahui persis (sync_script / delete) dengan pencatatan riwayat
async function runExact({ actions, label, origin, expect, undoOf, rel }) {
	if (!hasActivePlugin()) return { ok: false, msg: "No Studio connected" };
	const befores = [];
	for (const e of expect) befores.push(await fetchCurrent(e.segs));
	const r = await runUserBatch(actions, { label });
	if (!r.results) return { ok: false, msg: "No answer from Studio (timeout, or review is still waiting in Studio)" };
	const bad = r.results.find((x) => !x.ok);
	if (bad) return { ok: false, msg: String(bad.output || "gagal").split("\n")[0].slice(0, 400) };
	expect.forEach((e, i) => applyKnown(e, befores[i], { origin, label, batch: r.id, undoOf, rel }));
	return { ok: true };
}

// ================================================================ sinkronisasi folder lokal
const fileState = new Map(); // rel -> {mtimeMs,size,hash}
const manifest = new Map(); // key -> rel (file yang dikelola server)
const conflicts = new Map(); // rel -> {kind:"differs"|"local-only", key}
const syncIssues = []; // {t, kind, rel, msg}
const pushing = new Set();

function addIssue(kind, rel, msg) {
	const i = syncIssues.findIndex((x) => x.kind === kind && x.rel === rel);
	if (i >= 0) syncIssues.splice(i, 1);
	syncIssues.push({ t: Date.now(), kind, rel, msg: String(msg || "").slice(0, 400) });
	while (syncIssues.length > 30) syncIssues.shift();
}
function clearIssues(rel) {
	for (let i = syncIssues.length - 1; i >= 0; i--) if (syncIssues[i].rel === rel) syncIssues.splice(i, 1);
}

function safeJoin(rel) {
	const abs = path.resolve(SYNC_DIR, ...rel.split("/"));
	if (abs !== SYNC_DIR && !abs.startsWith(SYNC_DIR + path.sep)) throw new Error("path di luar folder sinkron: " + rel);
	return abs;
}

function relFor(v) {
	const key = fsmap.keyOf(v.segs);
	const hasKids = parentsSet.has(key);
	const known = manifest.get(key);
	if (known && !hasKids) {
		// pertahankan nama file yang sudah ada (mis. init.server.lua buatan user) selama masih memetakan script yang sama
		const m = fsmap.relToSegs(known);
		if (m && fsmap.keyOf(m.segs) === key && m.cls === v.cls) return known;
	}
	return fsmap.segsToRel(v.segs, v.cls, hasKids);
}

function listFiles() {
	const out = new Map();
	(function walk(dir, prefix) {
		let ents;
		try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
		for (const en of ents) {
			if (en.isSymbolicLink() || en.name.startsWith(".") || en.name === "node_modules") continue;
			const rel = prefix ? prefix + "/" + en.name : en.name;
			if (en.isDirectory()) walk(path.join(dir, en.name), rel);
			else if (en.isFile() && /\.(lua|luau)$/i.test(en.name)) {
				try {
					const st = fs.statSync(path.join(dir, en.name));
					out.set(rel, { mtimeMs: st.mtimeMs, size: st.size });
				} catch (e) {}
			}
		}
	})(SYNC_DIR, "");
	return out;
}

function pruneEmptyDirs(abs) {
	let dir = path.dirname(abs);
	while (dir.startsWith(SYNC_DIR + path.sep)) {
		try {
			if (fs.readdirSync(dir).length) break;
			fs.rmdirSync(dir);
		} catch (e) { break; }
		dir = path.dirname(dir);
	}
}

// Tulis satu script ke file. prevSource: isi yang seharusnya masih ada di disk (deteksi edit lokal yang belum terkirim)
function writeScriptFile(key, rel, source, prevSource) {
	const abs = safeJoin(rel);
	let disk = null;
	try { disk = fs.readFileSync(abs, "utf8"); } catch (e) {}
	if (disk !== null) {
		const d = fsmap.norm(disk);
		if (d === fsmap.norm(source)) {
			const st = fs.statSync(abs);
			fileState.set(rel, { mtimeMs: st.mtimeMs, size: st.size, hash: fsmap.hash(source) });
			manifest.set(key, rel);
			conflicts.delete(rel);
			return true;
		}
		if (prevSource === undefined || d !== fsmap.norm(prevSource)) {
			conflicts.set(rel, { kind: "differs", key });
			addIssue("conflict", rel, "File has local edits that differ from Studio; not overwritten.");
			return false;
		}
	}
	fs.mkdirSync(path.dirname(abs), { recursive: true });
	fs.writeFileSync(abs, fsmap.norm(source) + "\n", "utf8");
	const st = fs.statSync(abs);
	fileState.set(rel, { mtimeMs: st.mtimeMs, size: st.size, hash: fsmap.hash(source) });
	manifest.set(key, rel);
	conflicts.delete(rel);
	clearIssues(rel);
	return true;
}

function removeScriptFile(key, expectedSource) {
	const rel = manifest.get(key);
	if (!rel) return;
	manifest.delete(key);
	try {
		const abs = safeJoin(rel);
		const disk = fs.readFileSync(abs, "utf8");
		if (expectedSource != null && fsmap.norm(disk) !== fsmap.norm(expectedSource)) {
			addIssue("conflict", rel, "Script was deleted in Studio, but the file has local edits; file kept.");
			return;
		}
		fs.unlinkSync(abs);
		fileState.delete(rel);
		conflicts.delete(rel);
		pruneEmptyDirs(abs);
	} catch (e) {}
}

// Terapkan perubahan snapshot ke disk. changes: [{key,segs,cls,before,after}]
function syncDisk(changes) {
	try {
		const claimed = new Set();
		for (const rel of manifest.values()) claimed.add(rel.toLowerCase());
		for (const c of changes) {
			if (c.after === null) { removeScriptFile(c.key, c.before); continue; }
			const v = snap.get(c.key);
			if (!v) continue;
			const rel = relFor(v);
			if (!rel) continue;
			const old = manifest.get(c.key);
			if (old && old !== rel) {
				// berpindah (mis. script mendapat anak -> jadi folder/init.*)
				removeScriptFile(c.key, c.before);
				claimed.delete(old.toLowerCase());
			}
			if (!old && claimed.has(rel.toLowerCase())) { addIssue("conflict", rel, "Two scripts map to the same file name; the second one is skipped."); continue; }
			claimed.add(rel.toLowerCase());
			writeScriptFile(c.key, rel, c.after, c.before === null ? undefined : c.before);
		}
		// script lain yang kemungkinan berubah status folder/init karena perubahan di atas
		for (const [key, v] of snap) {
			const old = manifest.get(key);
			if (!old) continue;
			const rel = relFor(v);
			if (rel && rel !== old) {
				removeScriptFile(key, v.source);
				writeScriptFile(key, rel, v.source, v.source);
			}
		}
	} catch (e) {
		addIssue("error", "", "Gagal menulis file: " + e.message);
	}
}

// Pertama kali tersambung: ambil foto Studio, isi folder yang belum ada, tandai yang berbeda sebagai konflik
let baselineTimer = null;
function scheduleBaseline(why) {
	if (baselineTimer) return;
	baselineTimer = setTimeout(() => {
		baselineTimer = null;
		serial(() => baseline(why)).catch((e) => console.log("[sync] baseline gagal: " + e.message));
	}, 1500);
}

async function baseline(why) {
	if (!hasActivePlugin()) return;
	if (baselineDone && snapSid === activeSid && why !== "manual") return;
	const m = await dumpAll();
	if (!m) { addIssue("error", "", "Could not read scripts from Studio (will retry)."); return; }
	snap.clear();
	for (const [k, v] of m) snap.set(k, v);
	rebuildParents();
	snapSid = activeSid;
	snapAt = Date.now();
	baselineDone = true;
	console.log(`[sync] ${snap.size} script terbaca dari Studio (${why})`);
	if (!config.syncEnabled) return;
	seedDisk();
}

function seedDisk() {
	fs.mkdirSync(SYNC_DIR, { recursive: true });
	fileState.clear();
	manifest.clear();
	conflicts.clear();
	const files = listFiles();
	// 1) catat semua file yang sudah ada sebagai kondisi awal (tidak dianggap "perubahan baru")
	const byRel = new Map();
	for (const [rel, st] of files) {
		let content = null;
		try { content = fs.readFileSync(safeJoin(rel), "utf8"); } catch (e) { continue; }
		fileState.set(rel, { mtimeMs: st.mtimeMs, size: st.size, hash: fsmap.hash(content) });
		byRel.set(rel, content);
	}
	// 2) tulis script Studio yang belum punya file; tandai perbedaan
	const claimed = new Set();
	let written = 0;
	for (const [key, v] of snap) {
		let rel = relFor(v);
		if (!rel) continue;
		if (!byRel.has(rel)) {
			// file yang sudah ada bisa memakai bentuk lain (Name.server.lua <-> Name/init.server.lua)
			const alt = fsmap.segsToRel(v.segs, v.cls, !parentsSet.has(key));
			if (alt && byRel.has(alt) && !claimed.has(alt.toLowerCase())) rel = alt;
		}
		if (claimed.has(rel.toLowerCase())) { addIssue("conflict", rel, "Two scripts map to the same file name; the second one is skipped."); continue; }
		claimed.add(rel.toLowerCase());
		manifest.set(key, rel);
		if (byRel.has(rel)) {
			if (fsmap.norm(byRel.get(rel)) !== fsmap.norm(v.source)) conflicts.set(rel, { kind: "differs", key });
		} else {
			try { if (writeScriptFile(key, rel, v.source)) written++; } catch (e) { addIssue("error", rel, e.message); }
		}
	}
	// 3) file lokal yang tidak ada padanannya di Studio
	for (const [rel, content] of byRel) {
		const m = fsmap.relToSegs(rel);
		if (!m) { addIssue("ignored", rel, "Not mapped: needs <Service>/.../Name[.server|.client].lua"); continue; }
		const key = fsmap.keyOf(m.segs);
		if (!snap.has(key)) conflicts.set(rel, { kind: "local-only", key });
	}
	console.log(`[sync] folder ${SYNC_DIR}: ${written} file ditulis, ${conflicts.size} perlu keputusan`);
}

// Pemantau folder (polling 1 dtk: lintas-platform & tanpa dependency)
function scanTick() {
	if (!config.syncEnabled || !baselineDone || !hasActivePlugin()) return;
	const files = listFiles();
	for (const [rel, st] of files) {
		const f0 = fileState.get(rel);
		if (f0 && f0.mtimeMs === st.mtimeMs && f0.size === st.size) continue;
		if (Date.now() - st.mtimeMs < 350 || pushing.has(rel)) continue; // editor masih menulis
		let content;
		try { content = fs.readFileSync(safeJoin(rel), "utf8"); } catch (e) { continue; }
		const h = fsmap.hash(content);
		if (f0 && f0.hash === h) { f0.mtimeMs = st.mtimeMs; f0.size = st.size; continue; }
		const m = fsmap.relToSegs(rel);
		fileState.set(rel, { mtimeMs: st.mtimeMs, size: st.size, hash: h });
		if (!m) { addIssue("ignored", rel, "Not mapped: needs <Service>/.../Name[.server|.client].lua"); continue; }
		const key = fsmap.keyOf(m.segs);
		const cur = snap.get(key);
		if (cur && fsmap.norm(cur.source) === fsmap.norm(content)) { manifest.set(key, rel); conflicts.delete(rel); clearIssues(rel); continue; }
		pushFile(rel, m, content);
	}
	for (const rel of [...fileState.keys()]) {
		if (!files.has(rel)) { fileState.delete(rel); conflicts.delete(rel); }
	}
}

function pushFile(rel, m, content) {
	if (pushing.has(rel)) return Promise.resolve();
	pushing.add(rel);
	const src = fsmap.norm(content);
	return serial(async () => {
		try {
			const r = await runExact({
				actions: [{ tool: "sync_script", path: m.segs, class: m.cls, source: src }],
				label: "file: " + rel,
				origin: "vscode",
				rel,
				expect: [{ segs: m.segs, cls: m.cls, source: src }],
			});
			if (r.ok) {
				conflicts.delete(rel);
				clearIssues(rel);
				manifest.set(fsmap.keyOf(m.segs), rel);
				console.log("[sync] file -> Studio: " + rel);
			} else {
				addIssue("push-error", rel, r.msg);
				console.log("[sync] gagal kirim " + rel + ": " + r.msg);
			}
		} finally {
			pushing.delete(rel);
		}
	}).catch((e) => addIssue("push-error", rel, e.message));
}

async function pushAllConflicts() {
	const list = [...conflicts.entries()];
	let ok = 0, fail = 0;
	for (const [rel] of list) {
		const m = fsmap.relToSegs(rel);
		if (!m) { fail++; continue; }
		let content;
		try { content = fs.readFileSync(safeJoin(rel), "utf8"); } catch (e) { fail++; continue; }
		await pushFile(rel, m, content);
		if (conflicts.has(rel)) fail++; else ok++;
	}
	setLastJob("Push files to Studio", fail === 0, ok + " pushed" + (fail ? ", " + fail + " failed (see sync issues)" : ""));
}

function pullAllConflicts() {
	let n = 0;
	const stamp = new Date().toISOString().replace(/[:.]/g, "-");
	for (const [rel, c] of [...conflicts.entries()]) {
		if (c.kind !== "differs") continue;
		const v = snap.get(c.key);
		if (!v) continue;
		try {
			const abs = safeJoin(rel);
			const bak = path.join(DATA_DIR, "backup", stamp, ...rel.split("/"));
			fs.mkdirSync(path.dirname(bak), { recursive: true });
			fs.copyFileSync(abs, bak);
			fs.writeFileSync(abs, fsmap.norm(v.source) + "\n", "utf8");
			const st = fs.statSync(abs);
			fileState.set(rel, { mtimeMs: st.mtimeMs, size: st.size, hash: fsmap.hash(v.source) });
			manifest.set(c.key, rel);
			conflicts.delete(rel);
			clearIssues(rel);
			n++;
		} catch (e) { addIssue("error", rel, e.message); }
	}
	setLastJob("Pull Studio -> files", true, n + " file(s) overwritten from Studio (old versions are in server/.rs_data/backup)");
}

setInterval(() => { try { scanTick(); } catch (e) { console.log("[sync] scan error: " + e.message); } }, 1000).unref();

// ================================================================ pekerjaan terlacak (AI, makro, undo)
function trackedUserBatch(batch, label) {
	return serial(async () => {
		let pre = await dumpAll();
		if (pre) absorbStudioChanges(pre);
		else if (baselineDone) pre = new Map(snap);
		const waitP = new Promise((resolve) => {
			const timer = setTimeout(() => { jobWaiters.delete(batch.id); resolve(null); }, 5 * 60 * 1000);
			jobWaiters.set(batch.id, (list) => { clearTimeout(timer); resolve(list); });
		});
		enqueue(batch);
		const res = await waitP;
		if (!pre || !res) return;
		const post = await dumpAll();
		if (!post) return;
		reconcile(pre, post, { origin: "ai", batch: batch.id, label });
	}).catch((e) => console.log("[history] pelacakan gagal: " + e.message));
}

function existsDotted(m, dotted) {
	for (const v of m.values()) if (fsmap.dotted(v.segs) === dotted) return true;
	return false;
}

function runMacro(name, preview) {
	let tools;
	try { tools = loadTools(); } catch (e) { return Promise.reject(new Error("tools.json tidak terbaca: " + e.message)); }
	const defs = tools.commands || {};
	if (!Object.prototype.hasOwnProperty.call(defs, name)) return Promise.reject(new Error("makro tidak dikenal: " + name));
	const def = defs[name];
	if (preview && !def.preview) preview = false;
	const label = "⚡ " + name + (preview ? " (preview)" : "");
	return serial(async () => {
		if (!hasActivePlugin()) { setLastJob(label, false, "No Studio connected"); return; }
		const pre = await dumpAll();
		if (pre) absorbStudioChanges(pre);
		const actions = [];
		const skipped = [];
		for (const a0 of def.actions || []) {
			if (preview && a0.skip_on_preview) continue;
			if (a0.unless_exists && pre && existsDotted(pre, a0.unless_exists)) { skipped.push(a0.unless_exists); continue; }
			const a = {};
			for (const [k, v] of Object.entries(a0)) {
				if (k === "unless_exists" || k === "skip_on_preview") continue;
				a[k] = resolveMacroValue(v);
			}
			if (a.tool === "run_luau") {
				const code = a.code !== undefined ? "code" : "source";
				a[code] = "local DRY_RUN = " + (preview ? "true" : "false") + "\n" + a[code];
			}
			actions.push(a);
		}
		if (!actions.length) { setLastJob(label, true, "Nothing to do: already present (" + skipped.join(", ") + ")"); return; }
		const r = await runUserBatch(actions, { label });
		if (!r.results) { setLastJob(label, false, "No answer from Studio (timeout, or review is still waiting in Studio)"); return; }
		const ok = r.results.every((x) => x.ok);
		setLastJob(label, ok, r.results.map((x) => x.tool + ": " + String(x.output || "")).join("\n") + (skipped.length ? "\n(skipped, already exist: " + skipped.join(", ") + ")" : ""));
		if (pre && !preview) {
			const post = await dumpAll();
			if (post) reconcile(pre, post, { origin: "macro", batch: r.id, label });
		}
	});
}

function undoVersion(vid) {
	const v = versions.find((x) => x.vid === vid);
	if (!v) return Promise.reject(new Error("versi tidak ditemukan"));
	const label = "↩ undo v" + vid + " " + fsmap.dotted(v.segs);
	return serial(async () => {
		let r;
		if (v.before === null) {
			// script itu dibuat oleh perubahan ini -> undo = hapus (lewat review di Studio)
			r = await runExact({
				actions: [{ tool: "delete_instance", path: fsmap.dotted(v.segs) }],
				label, origin: "undo", undoOf: vid,
				expect: [{ segs: v.segs, cls: v.cls, source: null }],
			});
		} else {
			r = await runExact({
				actions: [{ tool: "sync_script", path: v.segs, class: v.cls, source: v.before }],
				label, origin: "undo", undoOf: vid,
				expect: [{ segs: v.segs, cls: v.cls, source: v.before }],
			});
		}
		setLastJob(label, r.ok, r.ok ? "Restored " + fsmap.dotted(v.segs) : r.msg);
	});
}

// ================================================================ dekorasi error untuk dashboard
function decorateEvent(e) {
	const out = { seq: e.seq, t: e.t, time: e.time, source: e.source, level: e.level, msg: e.msg };
	const h = hintFor(e.msg);
	if (h) out.hint = h;
	const loc = locate(e.msg);
	if (loc) {
		out.ref = loc;
		for (const v of snap.values()) {
			if (fsmap.dotted(v.segs) === loc.path) {
				const lines = v.source.replace(/\r\n?/g, "\n").split("\n");
				const from = Math.max(1, loc.line - 4), to = Math.min(lines.length, loc.line + 4);
				const ctx = [];
				for (let i = from; i <= to; i++) ctx.push({ n: i, s: lines[i - 1].slice(0, 200), hit: i === loc.line });
				out.context = ctx;
				break;
			}
		}
	}
	return out;
}

const ALLOWED_HOSTS = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);

const server = http.createServer(async (req, res) => {
	// 1) Host harus localhost (anti DNS-rebinding)
	if (!ALLOWED_HOSTS.has(String(req.headers.host || "").toLowerCase())) {
		return send(res, 403, { error: "host ditolak" });
	}
	// 2) Origin (kalau ada) harus dari ekstensi browser
	const origin = req.headers.origin;
	// Diizinkan: ekstensi browser dan dashboard milik server ini sendiri (Origin web lain ditolak)
	const OWN = origin === "http://127.0.0.1:" + PORT || origin === "http://localhost:" + PORT;
	if (origin && !OWN && !origin.startsWith("chrome-extension://") && !origin.startsWith("moz-extension://")) {
		return send(res, 403, { error: "origin ditolak" });
	}

	const url = new URL(req.url, `http://${HOST}:${PORT}`);

	// Satu-satunya endpoint tanpa token: untuk cek server hidup
	if (req.method === "GET" && url.pathname === "/health") {
		return send(res, 200, { ok: true, v: VERSION });
	}
	// Dashboard (halaman web lokal). Token disematkan ke HTML; situs lain tidak bisa membacanya
	// (same-origin policy + Host/Origin dicek + CSP). Permintaan lintas-situs ditolak.
	if (req.method === "GET" && url.pathname === "/") {
		if (req.headers["sec-fetch-site"] === "cross-site") return send(res, 403, { error: "ditolak" });
		try {
			const html = fs.readFileSync(DASH_FILE, "utf8").replace(/\{\{TOKEN\}\}/g, TOKEN).replace(/\{\{PORT\}\}/g, String(PORT));
			res.writeHead(200, {
				"Content-Type": "text/html; charset=utf-8",
				"Cache-Control": "no-store",
				"X-Frame-Options": "DENY",
				"Content-Security-Policy": "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'",
			});
			return res.end(html);
		} catch (e) {
			return send(res, 500, { error: "dashboard.html tidak ditemukan" });
		}
	}
	if (req.method === "GET" && url.pathname === "/logo.png") {
		try {
			res.writeHead(200, { "Content-Type": "image/png", "Cache-Control": "max-age=3600" });
			return res.end(fs.readFileSync(LOGO_FILE));
		} catch (e) {
			return send(res, 404, { error: "logo tidak ada" });
		}
	}
	// Pairing otomatis: hanya aktif 60 detik setelah user menekan "Hubungkan" di dashboard.
	// Origin web biasa sudah ditolak di atas; hanya ekstensi atau plugin Studio (tanpa Origin) yang lolos.
	if (req.method === "POST" && url.pathname === "/pair/claim") {
		if (Date.now() > pairUntil) return send(res, 403, { error: "jendela pairing belum dibuka (klik Hubungkan di dashboard)" });
		console.log("[pair] token diberikan ke " + (origin ? "ekstensi" : "plugin/aplikasi lokal"));
		return send(res, 200, { token: TOKEN });
	}

	// 3) Token wajib
	if (!tokenOk(req.headers["x-rs-token"])) {
		return send(res, 401, { error: "token salah atau kosong" });
	}

	try {
		if (req.method === "GET" && url.pathname === "/status") {
			pruneAndActive();
			const now = Date.now();
			return send(res, 200, {
				ok: true,
				v: VERSION,
				pluginConnected: pluginConnected(),
				activeSid,
				plugins: [...plugins.values()].map((p) => ({
					sid: p.sid,
					name: p.name,
					active: p.sid === activeSid,
					idle: Math.round((now - p.seen) / 1000),
				})),
				queued: (plugins.get(activeSid) ? plugins.get(activeSid).queue.length : 0) + pendingQueue.length,
				eventSeq,
			});
		}

		if (req.method === "GET" && url.pathname === "/api/state") {
			pruneAndActive();
			const now = Date.now();
			const lastByKey = new Map();
			for (const v of versions) lastByKey.set(v.key, v.vid);
			return send(res, 200, {
				v: VERSION,
				uptime: Math.round((now - STARTED) / 1000),
				pluginConnected: pluginConnected(),
				plugins: [...plugins.values()].map((p) => ({ sid: p.sid, name: p.name, active: p.sid === activeSid, idle: Math.round((now - p.seen) / 1000) })),
				pairing: { open: now < pairUntil, secondsLeft: Math.max(0, Math.round((pairUntil - now) / 1000)) },
				history: history.slice(0, 40),
				errors: events.filter((e) => e.level === "error").slice(-20).reverse().map(decorateEvent),
				errorSeq: events.reduce((m, e) => (e.level === "error" && e.seq > m ? e.seq : m), 0),
				sync: {
					enabled: config.syncEnabled,
					dir: SYNC_DIR,
					ready: baselineDone,
					scripts: snap.size,
					files: fileState.size,
					conflicts: [...conflicts.entries()].slice(0, 60).map(([rel, c]) => ({ rel, kind: c.kind })),
					conflictCount: conflicts.size,
					issues: syncIssues.slice(-8).reverse(),
					pushing: pushing.size,
					lastSync: snapAt,
				},
				versions: versions.slice(-80).reverse().map((v) => ({
					vid: v.vid, t: v.t, path: fsmap.dotted(v.segs), cls: v.cls, origin: v.origin, batch: v.batch, label: v.label,
					add: v.add, del: v.del, created: v.before === null, deleted: v.after === null, undoOf: v.undoOf,
					latest: lastByKey.get(v.key) === v.vid,
				})),
				lastJob,
				busy: busyJobs,
			});
		}
		if (req.method === "GET" && url.pathname === "/api/tools") {
			return send(res, 200, loadTools());
		}
		if (req.method === "POST" && url.pathname === "/api/pair/open") {
			pairUntil = Date.now() + 60000;
			console.log("[pair] jendela pairing dibuka 60 detik");
			return send(res, 200, { ok: true, seconds: 60 });
		}

		// ---------- makro, riwayat/undo, sinkronisasi (dipanggil dari dashboard)
		if (req.method === "POST" && url.pathname === "/api/macro/run") {
			const body = await readJson(req);
			if (!hasActivePlugin()) return send(res, 409, { error: "Studio belum tersambung" });
			runMacro(String(body.name || ""), body.preview === true).catch((e) => setLastJob("macro", false, e.message));
			return send(res, 200, { ok: true });
		}
		if (req.method === "GET" && url.pathname === "/api/history/diff") {
			const v = versions.find((x) => x.vid === Number(url.searchParams.get("vid")));
			if (!v) return send(res, 404, { error: "versi tidak ditemukan" });
			const d = diffLines(v.before || "", v.after || "");
			let ops = compact(d.ops, 3);
			let cut = false;
			if (ops.length > 800) { ops = ops.slice(0, 800); cut = true; }
			return send(res, 200, { vid: v.vid, path: fsmap.dotted(v.segs), add: d.add, del: d.del, created: v.before === null, deleted: v.after === null, ops, cut });
		}
		if (req.method === "POST" && url.pathname === "/api/history/undo") {
			const body = await readJson(req);
			const vid = Number(body.vid);
			if (!versions.find((x) => x.vid === vid)) return send(res, 404, { error: "versi tidak ditemukan" });
			if (!hasActivePlugin()) return send(res, 409, { error: "Studio belum tersambung" });
			undoVersion(vid).catch((e) => setLastJob("undo", false, e.message));
			return send(res, 200, { ok: true });
		}
		if (req.method === "POST" && url.pathname === "/api/sync/toggle") {
			const body = await readJson(req);
			config.syncEnabled = body.enabled === true;
			saveConfig();
			console.log("[sync] " + (config.syncEnabled ? "dinyalakan" : "dimatikan"));
			if (config.syncEnabled && baselineDone) {
				try { seedDisk(); } catch (e) { addIssue("error", "", e.message); }
			}
			return send(res, 200, { ok: true, enabled: config.syncEnabled });
		}
		if (req.method === "POST" && url.pathname === "/api/sync/resync") {
			if (!hasActivePlugin()) return send(res, 409, { error: "Studio belum tersambung" });
			serial(async () => {
				if (!baselineDone) return baseline("manual");
				const fresh = await dumpAll();
				if (!fresh) { addIssue("error", "", "Could not read scripts from Studio."); return; }
				const n = absorbStudioChanges(fresh);
				setLastJob("Re-sync from Studio", true, n ? n + " script change(s) found in Studio and written to files" : "Studio and files are already in sync");
			}).catch((e) => addIssue("error", "", e.message));
			return send(res, 200, { ok: true });
		}
		if (req.method === "POST" && url.pathname === "/api/sync/push") {
			if (!hasActivePlugin()) return send(res, 409, { error: "Studio belum tersambung" });
			pushAllConflicts().catch((e) => setLastJob("push", false, e.message));
			return send(res, 200, { ok: true });
		}
		if (req.method === "POST" && url.pathname === "/api/sync/pull") {
			pullAllConflicts();
			return send(res, 200, { ok: true });
		}
		if (req.method === "POST" && url.pathname === "/api/sync/open") {
			fs.mkdirSync(SYNC_DIR, { recursive: true });
			const cmd = process.platform === "win32" ? "explorer" : process.platform === "darwin" ? "open" : "xdg-open";
			try {
				const cp = require("child_process").spawn(cmd, [SYNC_DIR], { detached: true, stdio: "ignore" });
				cp.on("error", () => {});
				cp.unref();
			} catch (e) {}
			return send(res, 200, { ok: true });
		}

		// pilih Studio mana yang menerima perintah (kalau ada >1 jendela Studio)
		if (req.method === "POST" && url.pathname === "/select") {
			const body = await readJson(req);
			if (plugins.has(body.sid)) {
				activeSid = body.sid;
				scheduleBaseline("ganti Studio");
				return send(res, 200, { ok: true, activeSid });
			}
			return send(res, 404, { error: "plugin tidak ditemukan" });
		}

		// Plugin menandakan masih hidup (saat review / eksekusi panjang)
		if (req.method === "GET" && url.pathname === "/ping") {
			touchPlugin(url.searchParams.get("sid"));
			return send(res, 200, { ok: true });
		}

		if (req.method === "GET" && url.pathname === "/poll") {
			const p = touchPlugin(url.searchParams.get("sid"), url.searchParams.get("name"));
			if (p.waiter) {
				clearTimeout(p.waiter.timer);
				send(p.waiter.res, 200, {});
				p.waiter = null;
			}
			if (p.queue.length) return send(res, 200, p.queue.shift());
			const timer = setTimeout(() => {
				if (p.waiter && p.waiter.res === res) p.waiter = null;
				p.seen = Date.now();
				send(res, 200, {});
			}, POLL_HOLD_MS);
			p.waiter = { res, timer };
			req.on("close", () => {
				if (p.waiter && p.waiter.res === res) {
					clearTimeout(timer);
					p.waiter = null;
				}
			});
			return;
		}

		if (req.method === "POST" && url.pathname === "/commands") {
			const body = await readJson(req);
			if (!Array.isArray(body.actions) || body.actions.length === 0 || body.actions.length > 50) {
				return send(res, 400, { error: "actions harus berisi 1-50 aksi" });
			}
			if (!body.actions.every((a) => a && typeof a === "object" && typeof a.tool === "string")) {
				return send(res, 400, { error: "tiap aksi harus punya field tool" });
			}
			if (body.actions.some((a) => INTERNAL_TOOLS.has(a.tool))) {
				return send(res, 403, { error: "tool internal tidak boleh dipanggil lewat /commands" });
			}
			pruneAndActive();
			const id = nextId++;
			const batch = { id, actions: body.actions };
			cmdMeta.set(id, { t: Date.now(), tools: body.actions.map((a) => a.tool), label: null });
			for (const k of cmdMeta.keys()) if (k < id - 100) cmdMeta.delete(k);
			if (hasActivePlugin() && isTrackable(body.actions)) {
				trackedUserBatch(batch, null); // foto sebelum/sesudah -> riwayat + file lokal
			} else {
				enqueue(batch);
			}
			console.log(`[#${id}] ${body.actions.length} aksi: ${body.actions.map((a) => a.tool).join(", ")}`);
			return send(res, 200, { id, pluginConnected: pluginConnected() });
		}

		if (req.method === "POST" && url.pathname === "/results") {
			const body = await readJson(req, 30 * 1024 * 1024);
			const id = Number(body.id);
			const list = Array.isArray(body.results) ? body.results : [];
			// batch internal (dump / baca script): jangan masuk riwayat atau ekstensi
			const iw = internalWait.get(id);
			if (iw) { internalWait.delete(id); internalIds.delete(id); iw(list); return send(res, 200, { ok: true }); }
			if (internalIds.has(id)) { internalIds.delete(id); return send(res, 200, { ok: true }); }

			results.set(id, list);
			for (const k of results.keys()) if (k < nextId - 50) results.delete(k);
			const ok = list.filter((r) => r.ok).length;
			const meta = cmdMeta.get(id);
			cmdMeta.delete(id);
			history.unshift({
				id, time: Date.now(), tools: meta ? meta.tools : list.map((r) => r.tool), ok, total: list.length,
				ms: meta ? Date.now() - meta.t : null,
				execMs: Number.isFinite(Number(body.exec)) ? Math.round(Number(body.exec) * 1000) : null,
				label: meta && meta.label ? meta.label : null,
				detail: list.slice(0, 8).map((r) => ({ tool: String(r.tool), ok: !!r.ok, out: String(r.output == null ? "" : r.output).slice(0, 400) })),
			});
			if (history.length > 100) history.pop();
			console.log(`[#${id}] selesai: ${ok}/${list.length} berhasil`);
			const ws = resultWaiters.get(id);
			if (ws) {
				resultWaiters.delete(id);
				for (const w of ws) {
					clearTimeout(w.timer);
					send(w.res, 200, { done: true, results: list });
				}
			}
			const jw = jobWaiters.get(id);
			if (jw) { jobWaiters.delete(id); jw(list); }
			return send(res, 200, { ok: true });
		}

		// Ekstensi: ambil hasil. ?wait=1 -> long-poll (tahan sampai 15 dtk)
		if (req.method === "GET" && url.pathname === "/results") {
			const id = Number(url.searchParams.get("id"));
			if (results.has(id)) return send(res, 200, { done: true, results: results.get(id) });
			if (url.searchParams.get("wait") !== "1") return send(res, 200, { done: false });
			const w = { res };
			w.timer = setTimeout(() => {
				const arr = resultWaiters.get(id) || [];
				resultWaiters.set(id, arr.filter((x) => x !== w));
				send(res, 200, { done: false });
			}, RESULT_HOLD_MS);
			resultWaiters.set(id, [...(resultWaiters.get(id) || []), w]);
			req.on("close", () => clearTimeout(w.timer));
			return;
		}

		// Plugin mengirim error/warning dari Output Studio
		if (req.method === "POST" && url.pathname === "/events") {
			const body = await readJson(req);
			const source = String(body.source || "Studio");
			const now = Date.now();
			let added = 0;
			for (const it of Array.isArray(body.items) ? body.items.slice(0, 50) : []) {
				const level = it.level === "warning" ? "warning" : "error";
				const msg = String(it.msg || "").slice(0, 1500);
				if (!msg) continue;
				const dup = events.slice(-20).some((e) => e.level === level && e.msg === msg && now - e.t < 3000);
				if (dup) continue;
				events.push({ seq: ++eventSeq, t: now, time: new Date(now).toTimeString().slice(0, 8), source, level, msg });
				added++;
				if (level === "error") console.log(`[Studio/${source}] error: ${msg.split("\n")[0].slice(0, 140)}`);
			}
			while (events.length > 500) events.shift();
			return send(res, 200, { ok: true, added });
		}

		// Ekstensi: ambil error baru sejak seq tertentu
		if (req.method === "GET" && url.pathname === "/events") {
			const after = Number(url.searchParams.get("after")) || 0;
			const level = url.searchParams.get("level") || "error";
			const fresh = filterLevel(events.filter((e) => e.seq > after), level);
			return send(res, 200, { seq: eventSeq, events: fresh.slice(-30) });
		}

		// Riwayat Output (tool get_output & playtest). ?after=seq untuk hanya yang baru
		if (req.method === "GET" && url.pathname === "/log") {
			const limit = Math.min(Math.max(Number(url.searchParams.get("limit")) || 30, 1), 100);
			const level = url.searchParams.get("level") || "error";
			const after = Number(url.searchParams.get("after")) || 0;
			return send(res, 200, { events: filterLevel(events.filter((e) => e.seq > after), level).slice(-limit) });
		}

		send(res, 404, { error: "not found" });
	} catch (e) {
		send(res, 400, { error: String(e.message || e) });
	}
});

server.listen(PORT, HOST, () => {
	console.log("==============================================");
	console.log(" RobloxScripter server v" + VERSION + " di http://" + HOST + ":" + PORT);
	console.log("");
	console.log(" TOKEN KAMU (tempel di popup ekstensi & panel plugin Studio):");
	console.log("   " + TOKEN);
	console.log("");
	console.log(" DASHBOARD: http://" + HOST + ":" + PORT + "/   (klik 'Hubungkan' untuk pairing otomatis)");
	console.log(" Manual: tempel token di popup ekstensi & panel plugin Studio.");
	console.log(" (token baru: node server.js --new-token)");
	console.log("");
	console.log(" SINKRON FILE: " + (config.syncEnabled ? "AKTIF  -> " + SYNC_DIR : "mati (nyalakan di dashboard)"));
	console.log(" Buka folder itu di VS Code / Cursor: simpan file .lua = script di Studio ikut berubah.");
	console.log("==============================================");
	if (config.syncEnabled) { try { fs.mkdirSync(SYNC_DIR, { recursive: true }); } catch (e) {} }
	if (process.argv.includes("--open")) {
		const cmd = process.platform === "win32" ? 'start "" "' : process.platform === "darwin" ? 'open "' : 'xdg-open "';
		require("child_process").exec(cmd + "http://" + HOST + ":" + PORT + '/"');
	}
});
